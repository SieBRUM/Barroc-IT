﻿namespace Barroc_IT
{
    partial class frm_Finance_2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_Finance_2));
            this.mstrp_Menu = new System.Windows.Forms.MenuStrip();
            this.mnitem_Overview = new System.Windows.Forms.ToolStripMenuItem();
            this.mnfltr_Overview_Department = new System.Windows.Forms.ToolStripMenuItem();
            this.tscmb_Overview_Department = new System.Windows.Forms.ToolStripComboBox();
            this.mnfltr_Overview_Type = new System.Windows.Forms.ToolStripMenuItem();
            this.tscmb_Overview_Type = new System.Windows.Forms.ToolStripComboBox();
            this.mnfltr_Overview_Date = new System.Windows.Forms.ToolStripMenuItem();
            this.mnitem_Appointments = new System.Windows.Forms.ToolStripMenuItem();
            this.mnfltr_Appointments_CuName = new System.Windows.Forms.ToolStripMenuItem();
            this.tstxtb_Appointments_CuName = new System.Windows.Forms.ToolStripTextBox();
            this.mnfltr_Appointments_CoName = new System.Windows.Forms.ToolStripMenuItem();
            this.tstxtb_Appointments_CoName = new System.Windows.Forms.ToolStripTextBox();
            this.mnfltr_Appointments_Residence = new System.Windows.Forms.ToolStripMenuItem();
            this.tstxtb_Appointments_Residence = new System.Windows.Forms.ToolStripTextBox();
            this.mnfltr_Appointments_Summary = new System.Windows.Forms.ToolStripMenuItem();
            this.tscb_Appointments_Summary = new System.Windows.Forms.ToolStripComboBox();
            this.mnfltr_Appointments_Date = new System.Windows.Forms.ToolStripMenuItem();
            this.mnitem_Invoices = new System.Windows.Forms.ToolStripMenuItem();
            this.mnfltr_Invoices_CuName = new System.Windows.Forms.ToolStripMenuItem();
            this.tstxtb_Invoices_CuName = new System.Windows.Forms.ToolStripTextBox();
            this.mnfltr_Invoices_CoName = new System.Windows.Forms.ToolStripMenuItem();
            this.tstxtb_Invoices_CoName = new System.Windows.Forms.ToolStripTextBox();
            this.mnfltr_Invoices_Paid = new System.Windows.Forms.ToolStripMenuItem();
            this.tstxtb_Projects_CuName = new System.Windows.Forms.ToolStripTextBox();
            this.mnitem_Customers = new System.Windows.Forms.ToolStripMenuItem();
            this.mnfltr_Customers_CuName = new System.Windows.Forms.ToolStripMenuItem();
            this.tstxtb_Customers_CuName = new System.Windows.Forms.ToolStripTextBox();
            this.mnfltr_Customers_CoName = new System.Windows.Forms.ToolStripMenuItem();
            this.tstxtb_Customer_CoName = new System.Windows.Forms.ToolStripTextBox();
            this.mnfltr_Customers_Residence = new System.Windows.Forms.ToolStripMenuItem();
            this.mnfltr_Customers_UnpaidInvoice = new System.Windows.Forms.ToolStripMenuItem();
            this.mnitem_Logout = new System.Windows.Forms.ToolStripMenuItem();
            this.mnitem_Help = new System.Windows.Forms.ToolStripMenuItem();
            this.tcp_Help = new System.Windows.Forms.TabPage();
            this.label22 = new System.Windows.Forms.Label();
            this.richTextBox13 = new System.Windows.Forms.RichTextBox();
            this.richTextBox12 = new System.Windows.Forms.RichTextBox();
            this.richTextBox11 = new System.Windows.Forms.RichTextBox();
            this.richTextBox10 = new System.Windows.Forms.RichTextBox();
            this.richTextBox9 = new System.Windows.Forms.RichTextBox();
            this.richTextBox8 = new System.Windows.Forms.RichTextBox();
            this.richTextBox7 = new System.Windows.Forms.RichTextBox();
            this.richTextBox6 = new System.Windows.Forms.RichTextBox();
            this.richTextBox5 = new System.Windows.Forms.RichTextBox();
            this.richTextBox4 = new System.Windows.Forms.RichTextBox();
            this.richTextBox3 = new System.Windows.Forms.RichTextBox();
            this.richTextBox2 = new System.Windows.Forms.RichTextBox();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tcp_Edit_Customer = new System.Windows.Forms.TabPage();
            this.lbl_E_C_Customer_ID = new System.Windows.Forms.Label();
            this.btn_Edit_Customer = new System.Windows.Forms.Button();
            this.cb_E_C_Prospect = new System.Windows.Forms.ComboBox();
            this.cb_E_C_Creditworthy = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtb_E_C_Limit = new System.Windows.Forms.TextBox();
            this.txtb_E_C_GrossRevenue = new System.Windows.Forms.TextBox();
            this.txtb_E_C_Discount = new System.Windows.Forms.TextBox();
            this.txtb_E_C_Credit_Balance = new System.Windows.Forms.TextBox();
            this.txtb_E_C_IBAN = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.lbl_E_C_Customer = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label222 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.tcp_Customers = new System.Windows.Forms.TabPage();
            this.customerPanel = new System.Windows.Forms.Panel();
            this.btn_ShowAllCustomers = new System.Windows.Forms.Button();
            this.tcp_Appointments = new System.Windows.Forms.TabPage();
            this.appointmentsPanel = new System.Windows.Forms.Panel();
            this.btn_showallAppointments = new System.Windows.Forms.Button();
            this.tcp_AddInvoice = new System.Windows.Forms.TabPage();
            this.btn_Add_Invoice = new System.Windows.Forms.Button();
            this.lbl_Price = new System.Windows.Forms.Label();
            this.txtb_VAT = new System.Windows.Forms.TextBox();
            this.cbox_Project_Status = new System.Windows.Forms.ComboBox();
            this.lbl_Invoice_Status = new System.Windows.Forms.Label();
            this.lbl_VAT = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.cb_Select_Project = new System.Windows.Forms.ComboBox();
            this.lbl_Project_id = new System.Windows.Forms.Label();
            this.tcp_Invoices = new System.Windows.Forms.TabPage();
            this.btn_GoTo_Add_Invoice = new System.Windows.Forms.Button();
            this.invoicesPanel = new System.Windows.Forms.Panel();
            this.btn_ShowAllInvoices = new System.Windows.Forms.Button();
            this.tcp_Overview = new System.Windows.Forms.TabPage();
            this.notificationsPanel = new System.Windows.Forms.Panel();
            this.btn_Show_All_Notifications = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.tcp_Main = new System.Windows.Forms.TabControl();
            this.dtp_Payment_Deadline = new System.Windows.Forms.DateTimePicker();
            this.mstrp_Menu.SuspendLayout();
            this.tcp_Help.SuspendLayout();
            this.tcp_Edit_Customer.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.tcp_Customers.SuspendLayout();
            this.customerPanel.SuspendLayout();
            this.tcp_Appointments.SuspendLayout();
            this.appointmentsPanel.SuspendLayout();
            this.tcp_AddInvoice.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tcp_Invoices.SuspendLayout();
            this.invoicesPanel.SuspendLayout();
            this.tcp_Overview.SuspendLayout();
            this.notificationsPanel.SuspendLayout();
            this.tcp_Main.SuspendLayout();
            this.SuspendLayout();
            // 
            // mstrp_Menu
            // 
            this.mstrp_Menu.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.mstrp_Menu.AutoSize = false;
            this.mstrp_Menu.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.mstrp_Menu.Dock = System.Windows.Forms.DockStyle.None;
            this.mstrp_Menu.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mstrp_Menu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnitem_Overview,
            this.mnfltr_Overview_Department,
            this.mnfltr_Overview_Type,
            this.mnfltr_Overview_Date,
            this.mnitem_Appointments,
            this.mnfltr_Appointments_CuName,
            this.mnfltr_Appointments_CoName,
            this.mnfltr_Appointments_Residence,
            this.mnfltr_Appointments_Summary,
            this.mnfltr_Appointments_Date,
            this.mnitem_Invoices,
            this.mnfltr_Invoices_CuName,
            this.mnfltr_Invoices_CoName,
            this.mnfltr_Invoices_Paid,
            this.mnitem_Customers,
            this.mnfltr_Customers_CuName,
            this.mnfltr_Customers_CoName,
            this.mnfltr_Customers_Residence,
            this.mnfltr_Customers_UnpaidInvoice,
            this.mnitem_Logout,
            this.mnitem_Help});
            this.mstrp_Menu.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.VerticalStackWithOverflow;
            this.mstrp_Menu.Location = new System.Drawing.Point(0, 1);
            this.mstrp_Menu.Name = "mstrp_Menu";
            this.mstrp_Menu.Size = new System.Drawing.Size(142, 460);
            this.mstrp_Menu.TabIndex = 2;
            // 
            // mnitem_Overview
            // 
            this.mnitem_Overview.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.mnitem_Overview.Name = "mnitem_Overview";
            this.mnitem_Overview.Size = new System.Drawing.Size(135, 25);
            this.mnitem_Overview.Text = "Overview";
            this.mnitem_Overview.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.mnitem_Overview.Click += new System.EventHandler(this.MenuHandler);
            // 
            // mnfltr_Overview_Department
            // 
            this.mnfltr_Overview_Department.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tscmb_Overview_Department});
            this.mnfltr_Overview_Department.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.mnfltr_Overview_Department.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.mnfltr_Overview_Department.Margin = new System.Windows.Forms.Padding(10, 1, 1, 0);
            this.mnfltr_Overview_Department.Name = "mnfltr_Overview_Department";
            this.mnfltr_Overview_Department.Size = new System.Drawing.Size(124, 19);
            this.mnfltr_Overview_Department.Text = "Department";
            this.mnfltr_Overview_Department.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tscmb_Overview_Department
            // 
            this.tscmb_Overview_Department.BackColor = System.Drawing.SystemColors.Window;
            this.tscmb_Overview_Department.ForeColor = System.Drawing.SystemColors.WindowText;
            this.tscmb_Overview_Department.Items.AddRange(new object[] {
            "All",
            "Developement",
            "Finance",
            "Sales"});
            this.tscmb_Overview_Department.Name = "tscmb_Overview_Department";
            this.tscmb_Overview_Department.Size = new System.Drawing.Size(121, 23);
            this.tscmb_Overview_Department.Text = "All";
            // 
            // mnfltr_Overview_Type
            // 
            this.mnfltr_Overview_Type.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tscmb_Overview_Type});
            this.mnfltr_Overview_Type.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.mnfltr_Overview_Type.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.mnfltr_Overview_Type.Margin = new System.Windows.Forms.Padding(10, 1, 1, 0);
            this.mnfltr_Overview_Type.Name = "mnfltr_Overview_Type";
            this.mnfltr_Overview_Type.Size = new System.Drawing.Size(124, 19);
            this.mnfltr_Overview_Type.Text = "Type";
            this.mnfltr_Overview_Type.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tscmb_Overview_Type
            // 
            this.tscmb_Overview_Type.Items.AddRange(new object[] {
            "All",
            "Type1",
            "Type2",
            "Type3"});
            this.tscmb_Overview_Type.Name = "tscmb_Overview_Type";
            this.tscmb_Overview_Type.Size = new System.Drawing.Size(121, 23);
            this.tscmb_Overview_Type.Text = "All";
            // 
            // mnfltr_Overview_Date
            // 
            this.mnfltr_Overview_Date.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.mnfltr_Overview_Date.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.mnfltr_Overview_Date.Margin = new System.Windows.Forms.Padding(10, 1, 1, 0);
            this.mnfltr_Overview_Date.Name = "mnfltr_Overview_Date";
            this.mnfltr_Overview_Date.Size = new System.Drawing.Size(124, 19);
            this.mnfltr_Overview_Date.Text = "Date";
            this.mnfltr_Overview_Date.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // mnitem_Appointments
            // 
            this.mnitem_Appointments.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mnitem_Appointments.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.mnitem_Appointments.Name = "mnitem_Appointments";
            this.mnitem_Appointments.Size = new System.Drawing.Size(135, 25);
            this.mnitem_Appointments.Text = "Appointments";
            this.mnitem_Appointments.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.mnitem_Appointments.Click += new System.EventHandler(this.MenuHandler);
            // 
            // mnfltr_Appointments_CuName
            // 
            this.mnfltr_Appointments_CuName.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tstxtb_Appointments_CuName});
            this.mnfltr_Appointments_CuName.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.mnfltr_Appointments_CuName.Margin = new System.Windows.Forms.Padding(10, 1, 1, 0);
            this.mnfltr_Appointments_CuName.Name = "mnfltr_Appointments_CuName";
            this.mnfltr_Appointments_CuName.Size = new System.Drawing.Size(124, 19);
            this.mnfltr_Appointments_CuName.Text = "Customer Name";
            this.mnfltr_Appointments_CuName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tstxtb_Appointments_CuName
            // 
            this.tstxtb_Appointments_CuName.Name = "tstxtb_Appointments_CuName";
            this.tstxtb_Appointments_CuName.Size = new System.Drawing.Size(100, 23);
            // 
            // mnfltr_Appointments_CoName
            // 
            this.mnfltr_Appointments_CoName.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tstxtb_Appointments_CoName});
            this.mnfltr_Appointments_CoName.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.mnfltr_Appointments_CoName.Margin = new System.Windows.Forms.Padding(10, 1, 1, 0);
            this.mnfltr_Appointments_CoName.Name = "mnfltr_Appointments_CoName";
            this.mnfltr_Appointments_CoName.Size = new System.Drawing.Size(124, 19);
            this.mnfltr_Appointments_CoName.Text = "Company Name";
            this.mnfltr_Appointments_CoName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tstxtb_Appointments_CoName
            // 
            this.tstxtb_Appointments_CoName.Name = "tstxtb_Appointments_CoName";
            this.tstxtb_Appointments_CoName.Size = new System.Drawing.Size(100, 23);
            // 
            // mnfltr_Appointments_Residence
            // 
            this.mnfltr_Appointments_Residence.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tstxtb_Appointments_Residence});
            this.mnfltr_Appointments_Residence.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.mnfltr_Appointments_Residence.Margin = new System.Windows.Forms.Padding(10, 1, 1, 0);
            this.mnfltr_Appointments_Residence.Name = "mnfltr_Appointments_Residence";
            this.mnfltr_Appointments_Residence.Size = new System.Drawing.Size(124, 19);
            this.mnfltr_Appointments_Residence.Text = "Residence";
            this.mnfltr_Appointments_Residence.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tstxtb_Appointments_Residence
            // 
            this.tstxtb_Appointments_Residence.Name = "tstxtb_Appointments_Residence";
            this.tstxtb_Appointments_Residence.Size = new System.Drawing.Size(100, 23);
            // 
            // mnfltr_Appointments_Summary
            // 
            this.mnfltr_Appointments_Summary.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tscb_Appointments_Summary});
            this.mnfltr_Appointments_Summary.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.mnfltr_Appointments_Summary.Margin = new System.Windows.Forms.Padding(10, 1, 1, 0);
            this.mnfltr_Appointments_Summary.Name = "mnfltr_Appointments_Summary";
            this.mnfltr_Appointments_Summary.Size = new System.Drawing.Size(124, 19);
            this.mnfltr_Appointments_Summary.Text = "Summary";
            this.mnfltr_Appointments_Summary.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tscb_Appointments_Summary
            // 
            this.tscb_Appointments_Summary.Items.AddRange(new object[] {
            "All",
            "Yes",
            "No"});
            this.tscb_Appointments_Summary.Name = "tscb_Appointments_Summary";
            this.tscb_Appointments_Summary.Size = new System.Drawing.Size(121, 23);
            this.tscb_Appointments_Summary.Text = "All";
            // 
            // mnfltr_Appointments_Date
            // 
            this.mnfltr_Appointments_Date.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.mnfltr_Appointments_Date.Margin = new System.Windows.Forms.Padding(10, 1, 1, 0);
            this.mnfltr_Appointments_Date.Name = "mnfltr_Appointments_Date";
            this.mnfltr_Appointments_Date.Size = new System.Drawing.Size(124, 19);
            this.mnfltr_Appointments_Date.Text = "Date";
            this.mnfltr_Appointments_Date.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // mnitem_Invoices
            // 
            this.mnitem_Invoices.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mnitem_Invoices.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.mnitem_Invoices.Name = "mnitem_Invoices";
            this.mnitem_Invoices.Size = new System.Drawing.Size(135, 25);
            this.mnitem_Invoices.Text = "Invoices";
            this.mnitem_Invoices.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.mnitem_Invoices.Click += new System.EventHandler(this.MenuHandler);
            // 
            // mnfltr_Invoices_CuName
            // 
            this.mnfltr_Invoices_CuName.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tstxtb_Invoices_CuName});
            this.mnfltr_Invoices_CuName.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.mnfltr_Invoices_CuName.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.mnfltr_Invoices_CuName.Margin = new System.Windows.Forms.Padding(10, 1, 1, 0);
            this.mnfltr_Invoices_CuName.Name = "mnfltr_Invoices_CuName";
            this.mnfltr_Invoices_CuName.Size = new System.Drawing.Size(124, 19);
            this.mnfltr_Invoices_CuName.Text = "Customer name";
            this.mnfltr_Invoices_CuName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tstxtb_Invoices_CuName
            // 
            this.tstxtb_Invoices_CuName.Name = "tstxtb_Invoices_CuName";
            this.tstxtb_Invoices_CuName.Size = new System.Drawing.Size(100, 23);
            this.tstxtb_Invoices_CuName.KeyUp += new System.Windows.Forms.KeyEventHandler(this.SearchInvoiceOnCuName);
            // 
            // mnfltr_Invoices_CoName
            // 
            this.mnfltr_Invoices_CoName.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tstxtb_Invoices_CoName});
            this.mnfltr_Invoices_CoName.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.mnfltr_Invoices_CoName.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.mnfltr_Invoices_CoName.Margin = new System.Windows.Forms.Padding(10, 1, 1, 0);
            this.mnfltr_Invoices_CoName.Name = "mnfltr_Invoices_CoName";
            this.mnfltr_Invoices_CoName.Size = new System.Drawing.Size(124, 19);
            this.mnfltr_Invoices_CoName.Text = "Company name";
            this.mnfltr_Invoices_CoName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tstxtb_Invoices_CoName
            // 
            this.tstxtb_Invoices_CoName.Name = "tstxtb_Invoices_CoName";
            this.tstxtb_Invoices_CoName.Size = new System.Drawing.Size(100, 23);
            this.tstxtb_Invoices_CoName.KeyUp += new System.Windows.Forms.KeyEventHandler(this.SearchInvoiceOnCoName);
            // 
            // mnfltr_Invoices_Paid
            // 
            this.mnfltr_Invoices_Paid.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tstxtb_Projects_CuName});
            this.mnfltr_Invoices_Paid.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.mnfltr_Invoices_Paid.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.mnfltr_Invoices_Paid.Margin = new System.Windows.Forms.Padding(10, 1, 1, 0);
            this.mnfltr_Invoices_Paid.Name = "mnfltr_Invoices_Paid";
            this.mnfltr_Invoices_Paid.Size = new System.Drawing.Size(124, 19);
            this.mnfltr_Invoices_Paid.Text = "Paid/Unpaid";
            this.mnfltr_Invoices_Paid.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tstxtb_Projects_CuName
            // 
            this.tstxtb_Projects_CuName.Name = "tstxtb_Projects_CuName";
            this.tstxtb_Projects_CuName.Size = new System.Drawing.Size(100, 23);
            // 
            // mnitem_Customers
            // 
            this.mnitem_Customers.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.mnitem_Customers.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.mnitem_Customers.Name = "mnitem_Customers";
            this.mnitem_Customers.Size = new System.Drawing.Size(135, 25);
            this.mnitem_Customers.Text = "Customers";
            this.mnitem_Customers.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.mnitem_Customers.Click += new System.EventHandler(this.MenuHandler);
            // 
            // mnfltr_Customers_CuName
            // 
            this.mnfltr_Customers_CuName.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tstxtb_Customers_CuName});
            this.mnfltr_Customers_CuName.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.mnfltr_Customers_CuName.Margin = new System.Windows.Forms.Padding(10, 1, 1, 0);
            this.mnfltr_Customers_CuName.Name = "mnfltr_Customers_CuName";
            this.mnfltr_Customers_CuName.Size = new System.Drawing.Size(124, 19);
            this.mnfltr_Customers_CuName.Text = "Customer name";
            this.mnfltr_Customers_CuName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tstxtb_Customers_CuName
            // 
            this.tstxtb_Customers_CuName.Name = "tstxtb_Customers_CuName";
            this.tstxtb_Customers_CuName.Size = new System.Drawing.Size(100, 23);
            this.tstxtb_Customers_CuName.KeyUp += new System.Windows.Forms.KeyEventHandler(this.SearchCustomerOnCuName);
            // 
            // mnfltr_Customers_CoName
            // 
            this.mnfltr_Customers_CoName.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tstxtb_Customer_CoName});
            this.mnfltr_Customers_CoName.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.mnfltr_Customers_CoName.Margin = new System.Windows.Forms.Padding(10, 1, 1, 0);
            this.mnfltr_Customers_CoName.Name = "mnfltr_Customers_CoName";
            this.mnfltr_Customers_CoName.Size = new System.Drawing.Size(124, 19);
            this.mnfltr_Customers_CoName.Text = "Company name";
            this.mnfltr_Customers_CoName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tstxtb_Customer_CoName
            // 
            this.tstxtb_Customer_CoName.Name = "tstxtb_Customer_CoName";
            this.tstxtb_Customer_CoName.Size = new System.Drawing.Size(100, 23);
            this.tstxtb_Customer_CoName.KeyUp += new System.Windows.Forms.KeyEventHandler(this.SearchCustomerOnCoName);
            // 
            // mnfltr_Customers_Residence
            // 
            this.mnfltr_Customers_Residence.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.mnfltr_Customers_Residence.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.mnfltr_Customers_Residence.Margin = new System.Windows.Forms.Padding(10, 1, 1, 0);
            this.mnfltr_Customers_Residence.Name = "mnfltr_Customers_Residence";
            this.mnfltr_Customers_Residence.Size = new System.Drawing.Size(124, 19);
            this.mnfltr_Customers_Residence.Text = "Residence";
            this.mnfltr_Customers_Residence.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // mnfltr_Customers_UnpaidInvoice
            // 
            this.mnfltr_Customers_UnpaidInvoice.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.mnfltr_Customers_UnpaidInvoice.Margin = new System.Windows.Forms.Padding(10, 1, 1, 0);
            this.mnfltr_Customers_UnpaidInvoice.Name = "mnfltr_Customers_UnpaidInvoice";
            this.mnfltr_Customers_UnpaidInvoice.Size = new System.Drawing.Size(124, 19);
            this.mnfltr_Customers_UnpaidInvoice.Text = "Unpaid invoice";
            this.mnfltr_Customers_UnpaidInvoice.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // mnitem_Logout
            // 
            this.mnitem_Logout.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.mnitem_Logout.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mnitem_Logout.Name = "mnitem_Logout";
            this.mnitem_Logout.Size = new System.Drawing.Size(135, 25);
            this.mnitem_Logout.Text = "Logout";
            this.mnitem_Logout.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.mnitem_Logout.Click += new System.EventHandler(this.mnitem_Logout_Click);
            // 
            // mnitem_Help
            // 
            this.mnitem_Help.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.mnitem_Help.Checked = true;
            this.mnitem_Help.CheckState = System.Windows.Forms.CheckState.Checked;
            this.mnitem_Help.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.mnitem_Help.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.mnitem_Help.Margin = new System.Windows.Forms.Padding(0, 100, 0, 0);
            this.mnitem_Help.Name = "mnitem_Help";
            this.mnitem_Help.Size = new System.Drawing.Size(135, 25);
            this.mnitem_Help.Text = "Help";
            this.mnitem_Help.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.mnitem_Help.Click += new System.EventHandler(this.mnitem_Help_Click);
            // 
            // tcp_Help
            // 
            this.tcp_Help.AutoScroll = true;
            this.tcp_Help.Controls.Add(this.label22);
            this.tcp_Help.Controls.Add(this.richTextBox13);
            this.tcp_Help.Controls.Add(this.richTextBox12);
            this.tcp_Help.Controls.Add(this.richTextBox11);
            this.tcp_Help.Controls.Add(this.richTextBox10);
            this.tcp_Help.Controls.Add(this.richTextBox9);
            this.tcp_Help.Controls.Add(this.richTextBox8);
            this.tcp_Help.Controls.Add(this.richTextBox7);
            this.tcp_Help.Controls.Add(this.richTextBox6);
            this.tcp_Help.Controls.Add(this.richTextBox5);
            this.tcp_Help.Controls.Add(this.richTextBox4);
            this.tcp_Help.Controls.Add(this.richTextBox3);
            this.tcp_Help.Controls.Add(this.richTextBox2);
            this.tcp_Help.Controls.Add(this.richTextBox1);
            this.tcp_Help.Controls.Add(this.label20);
            this.tcp_Help.Controls.Add(this.label19);
            this.tcp_Help.Controls.Add(this.label18);
            this.tcp_Help.Controls.Add(this.label17);
            this.tcp_Help.Controls.Add(this.label16);
            this.tcp_Help.Controls.Add(this.label15);
            this.tcp_Help.Controls.Add(this.label14);
            this.tcp_Help.Controls.Add(this.label13);
            this.tcp_Help.Controls.Add(this.label12);
            this.tcp_Help.Controls.Add(this.label11);
            this.tcp_Help.Controls.Add(this.label9);
            this.tcp_Help.Controls.Add(this.label4);
            this.tcp_Help.Controls.Add(this.label1);
            this.tcp_Help.Controls.Add(this.label2);
            this.tcp_Help.Location = new System.Drawing.Point(4, 22);
            this.tcp_Help.Name = "tcp_Help";
            this.tcp_Help.Padding = new System.Windows.Forms.Padding(3);
            this.tcp_Help.Size = new System.Drawing.Size(566, 460);
            this.tcp_Help.TabIndex = 6;
            this.tcp_Help.Text = "Help";
            this.tcp_Help.UseVisualStyleBackColor = true;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(5, 1319);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(260, 16);
            this.label22.TabIndex = 35;
            this.label22.Text = "Hoe bewerk ik een bestaande klant?";
            // 
            // richTextBox13
            // 
            this.richTextBox13.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.richTextBox13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox13.Location = new System.Drawing.Point(6, 1319);
            this.richTextBox13.Name = "richTextBox13";
            this.richTextBox13.ReadOnly = true;
            this.richTextBox13.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None;
            this.richTextBox13.Size = new System.Drawing.Size(537, 87);
            this.richTextBox13.TabIndex = 34;
            this.richTextBox13.Text = resources.GetString("richTextBox13.Text");
            // 
            // richTextBox12
            // 
            this.richTextBox12.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.richTextBox12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox12.Location = new System.Drawing.Point(5, 1211);
            this.richTextBox12.Name = "richTextBox12";
            this.richTextBox12.ReadOnly = true;
            this.richTextBox12.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None;
            this.richTextBox12.Size = new System.Drawing.Size(537, 99);
            this.richTextBox12.TabIndex = 32;
            this.richTextBox12.Text = resources.GetString("richTextBox12.Text");
            // 
            // richTextBox11
            // 
            this.richTextBox11.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.richTextBox11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox11.Location = new System.Drawing.Point(6, 1120);
            this.richTextBox11.Name = "richTextBox11";
            this.richTextBox11.ReadOnly = true;
            this.richTextBox11.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None;
            this.richTextBox11.Size = new System.Drawing.Size(537, 84);
            this.richTextBox11.TabIndex = 30;
            this.richTextBox11.Text = resources.GetString("richTextBox11.Text");
            // 
            // richTextBox10
            // 
            this.richTextBox10.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.richTextBox10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox10.Location = new System.Drawing.Point(6, 1001);
            this.richTextBox10.Name = "richTextBox10";
            this.richTextBox10.ReadOnly = true;
            this.richTextBox10.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None;
            this.richTextBox10.Size = new System.Drawing.Size(537, 113);
            this.richTextBox10.TabIndex = 28;
            this.richTextBox10.Text = resources.GetString("richTextBox10.Text");
            // 
            // richTextBox9
            // 
            this.richTextBox9.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.richTextBox9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox9.Location = new System.Drawing.Point(6, 904);
            this.richTextBox9.Name = "richTextBox9";
            this.richTextBox9.ReadOnly = true;
            this.richTextBox9.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None;
            this.richTextBox9.Size = new System.Drawing.Size(537, 87);
            this.richTextBox9.TabIndex = 26;
            this.richTextBox9.Text = resources.GetString("richTextBox9.Text");
            // 
            // richTextBox8
            // 
            this.richTextBox8.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.richTextBox8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox8.Location = new System.Drawing.Point(6, 781);
            this.richTextBox8.Name = "richTextBox8";
            this.richTextBox8.ReadOnly = true;
            this.richTextBox8.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None;
            this.richTextBox8.Size = new System.Drawing.Size(537, 114);
            this.richTextBox8.TabIndex = 24;
            this.richTextBox8.Text = resources.GetString("richTextBox8.Text");
            // 
            // richTextBox7
            // 
            this.richTextBox7.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.richTextBox7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox7.Location = new System.Drawing.Point(5, 673);
            this.richTextBox7.Name = "richTextBox7";
            this.richTextBox7.ReadOnly = true;
            this.richTextBox7.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None;
            this.richTextBox7.Size = new System.Drawing.Size(537, 99);
            this.richTextBox7.TabIndex = 22;
            this.richTextBox7.Text = resources.GetString("richTextBox7.Text");
            // 
            // richTextBox6
            // 
            this.richTextBox6.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.richTextBox6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox6.Location = new System.Drawing.Point(6, 549);
            this.richTextBox6.Name = "richTextBox6";
            this.richTextBox6.ReadOnly = true;
            this.richTextBox6.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None;
            this.richTextBox6.Size = new System.Drawing.Size(537, 85);
            this.richTextBox6.TabIndex = 19;
            this.richTextBox6.Text = resources.GetString("richTextBox6.Text");
            // 
            // richTextBox5
            // 
            this.richTextBox5.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.richTextBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox5.Location = new System.Drawing.Point(7, 442);
            this.richTextBox5.Name = "richTextBox5";
            this.richTextBox5.ReadOnly = true;
            this.richTextBox5.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None;
            this.richTextBox5.Size = new System.Drawing.Size(537, 100);
            this.richTextBox5.TabIndex = 17;
            this.richTextBox5.Text = resources.GetString("richTextBox5.Text");
            // 
            // richTextBox4
            // 
            this.richTextBox4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.richTextBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox4.Location = new System.Drawing.Point(6, 348);
            this.richTextBox4.Name = "richTextBox4";
            this.richTextBox4.ReadOnly = true;
            this.richTextBox4.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None;
            this.richTextBox4.Size = new System.Drawing.Size(537, 87);
            this.richTextBox4.TabIndex = 15;
            this.richTextBox4.Text = resources.GetString("richTextBox4.Text");
            // 
            // richTextBox3
            // 
            this.richTextBox3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.richTextBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox3.Location = new System.Drawing.Point(6, 243);
            this.richTextBox3.Name = "richTextBox3";
            this.richTextBox3.ReadOnly = true;
            this.richTextBox3.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None;
            this.richTextBox3.Size = new System.Drawing.Size(537, 99);
            this.richTextBox3.TabIndex = 13;
            this.richTextBox3.Text = resources.GetString("richTextBox3.Text");
            // 
            // richTextBox2
            // 
            this.richTextBox2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.richTextBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox2.Location = new System.Drawing.Point(5, 138);
            this.richTextBox2.Name = "richTextBox2";
            this.richTextBox2.ReadOnly = true;
            this.richTextBox2.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None;
            this.richTextBox2.Size = new System.Drawing.Size(537, 99);
            this.richTextBox2.TabIndex = 11;
            this.richTextBox2.Text = resources.GetString("richTextBox2.Text");
            // 
            // richTextBox1
            // 
            this.richTextBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.richTextBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox1.Location = new System.Drawing.Point(4, 46);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.ReadOnly = true;
            this.richTextBox1.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None;
            this.richTextBox1.Size = new System.Drawing.Size(537, 83);
            this.richTextBox1.TabIndex = 9;
            this.richTextBox1.Text = resources.GetString("richTextBox1.Text");
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(4, 1211);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(235, 16);
            this.label20.TabIndex = 33;
            this.label20.Text = "Hoe bekijk ik de klantgegevens?";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(5, 1120);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(258, 16);
            this.label19.TabIndex = 31;
            this.label19.Text = "Hoe voeg ik een nieuwe factuur toe?";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(5, 1001);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(187, 16);
            this.label18.TabIndex = 29;
            this.label18.Text = "Hoe check ik de facturen?";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(5, 904);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(283, 16);
            this.label17.TabIndex = 27;
            this.label17.Text = "Hoe bewerk ik een gemaakte afspraak?";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(5, 781);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(201, 16);
            this.label16.TabIndex = 25;
            this.label16.Text = "Hoe check ik de afspraken?";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(4, 673);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(204, 16);
            this.label15.TabIndex = 23;
            this.label15.Text = "Hoe check ik de meldingen?";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(-7, 633);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(215, 39);
            this.label14.TabIndex = 21;
            this.label14.Text = "Nederlands:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(5, 549);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(186, 16);
            this.label13.TabIndex = 20;
            this.label13.Text = "How do I edit a customer?";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(6, 442);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(248, 16);
            this.label12.TabIndex = 18;
            this.label12.Text = "How do I check the customer data?\r\n";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(5, 348);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(205, 16);
            this.label11.TabIndex = 16;
            this.label11.Text = "How do I add a new invoice?";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(4, 243);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(208, 16);
            this.label9.TabIndex = 14;
            this.label9.Text = "How do I check the invoices?";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(3, 138);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(243, 16);
            this.label4.TabIndex = 12;
            this.label4.Text = "How do I check the appointments?\r\n";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(2, 46);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(233, 16);
            this.label1.TabIndex = 10;
            this.label1.Text = "How do I check the notifications?";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(-7, 3);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(149, 39);
            this.label2.TabIndex = 8;
            this.label2.Text = "English:";
            // 
            // tcp_Edit_Customer
            // 
            this.tcp_Edit_Customer.Controls.Add(this.lbl_E_C_Customer_ID);
            this.tcp_Edit_Customer.Controls.Add(this.btn_Edit_Customer);
            this.tcp_Edit_Customer.Controls.Add(this.cb_E_C_Prospect);
            this.tcp_Edit_Customer.Controls.Add(this.cb_E_C_Creditworthy);
            this.tcp_Edit_Customer.Controls.Add(this.label7);
            this.tcp_Edit_Customer.Controls.Add(this.label5);
            this.tcp_Edit_Customer.Controls.Add(this.txtb_E_C_Limit);
            this.tcp_Edit_Customer.Controls.Add(this.txtb_E_C_GrossRevenue);
            this.tcp_Edit_Customer.Controls.Add(this.txtb_E_C_Discount);
            this.tcp_Edit_Customer.Controls.Add(this.txtb_E_C_Credit_Balance);
            this.tcp_Edit_Customer.Controls.Add(this.txtb_E_C_IBAN);
            this.tcp_Edit_Customer.Controls.Add(this.label10);
            this.tcp_Edit_Customer.Controls.Add(this.lbl_E_C_Customer);
            this.tcp_Edit_Customer.Controls.Add(this.label8);
            this.tcp_Edit_Customer.Controls.Add(this.label6);
            this.tcp_Edit_Customer.Controls.Add(this.label21);
            this.tcp_Edit_Customer.Controls.Add(this.label222);
            this.tcp_Edit_Customer.Controls.Add(this.pictureBox2);
            this.tcp_Edit_Customer.Location = new System.Drawing.Point(4, 22);
            this.tcp_Edit_Customer.Name = "tcp_Edit_Customer";
            this.tcp_Edit_Customer.Padding = new System.Windows.Forms.Padding(3);
            this.tcp_Edit_Customer.Size = new System.Drawing.Size(566, 460);
            this.tcp_Edit_Customer.TabIndex = 5;
            this.tcp_Edit_Customer.Text = "Edit Customer";
            this.tcp_Edit_Customer.UseVisualStyleBackColor = true;
            // 
            // lbl_E_C_Customer_ID
            // 
            this.lbl_E_C_Customer_ID.AutoSize = true;
            this.lbl_E_C_Customer_ID.Location = new System.Drawing.Point(492, 54);
            this.lbl_E_C_Customer_ID.Name = "lbl_E_C_Customer_ID";
            this.lbl_E_C_Customer_ID.Size = new System.Drawing.Size(35, 13);
            this.lbl_E_C_Customer_ID.TabIndex = 49;
            this.lbl_E_C_Customer_ID.Text = "label1";
            this.lbl_E_C_Customer_ID.Visible = false;
            // 
            // btn_Edit_Customer
            // 
            this.btn_Edit_Customer.Location = new System.Drawing.Point(451, 403);
            this.btn_Edit_Customer.Name = "btn_Edit_Customer";
            this.btn_Edit_Customer.Size = new System.Drawing.Size(105, 23);
            this.btn_Edit_Customer.TabIndex = 48;
            this.btn_Edit_Customer.Text = "Edit Customer";
            this.btn_Edit_Customer.UseVisualStyleBackColor = true;
            this.btn_Edit_Customer.Click += new System.EventHandler(this.EditFinancialDetails);
            // 
            // cb_E_C_Prospect
            // 
            this.cb_E_C_Prospect.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_E_C_Prospect.FormattingEnabled = true;
            this.cb_E_C_Prospect.Items.AddRange(new object[] {
            "No",
            "Yes"});
            this.cb_E_C_Prospect.Location = new System.Drawing.Point(26, 304);
            this.cb_E_C_Prospect.Name = "cb_E_C_Prospect";
            this.cb_E_C_Prospect.Size = new System.Drawing.Size(121, 21);
            this.cb_E_C_Prospect.TabIndex = 47;
            // 
            // cb_E_C_Creditworthy
            // 
            this.cb_E_C_Creditworthy.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_E_C_Creditworthy.FormattingEnabled = true;
            this.cb_E_C_Creditworthy.Items.AddRange(new object[] {
            "No",
            "Yes"});
            this.cb_E_C_Creditworthy.Location = new System.Drawing.Point(26, 264);
            this.cb_E_C_Creditworthy.Name = "cb_E_C_Creditworthy";
            this.cb_E_C_Creditworthy.Size = new System.Drawing.Size(121, 21);
            this.cb_E_C_Creditworthy.TabIndex = 46;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(23, 288);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(52, 13);
            this.label7.TabIndex = 45;
            this.label7.Text = "Prospect:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(23, 248);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(68, 13);
            this.label5.TabIndex = 44;
            this.label5.Text = "Creditworthy:";
            // 
            // txtb_E_C_Limit
            // 
            this.txtb_E_C_Limit.Location = new System.Drawing.Point(26, 225);
            this.txtb_E_C_Limit.Name = "txtb_E_C_Limit";
            this.txtb_E_C_Limit.Size = new System.Drawing.Size(141, 20);
            this.txtb_E_C_Limit.TabIndex = 43;
            // 
            // txtb_E_C_GrossRevenue
            // 
            this.txtb_E_C_GrossRevenue.Location = new System.Drawing.Point(387, 266);
            this.txtb_E_C_GrossRevenue.Name = "txtb_E_C_GrossRevenue";
            this.txtb_E_C_GrossRevenue.Size = new System.Drawing.Size(141, 20);
            this.txtb_E_C_GrossRevenue.TabIndex = 41;
            // 
            // txtb_E_C_Discount
            // 
            this.txtb_E_C_Discount.Location = new System.Drawing.Point(387, 226);
            this.txtb_E_C_Discount.MaxLength = 2;
            this.txtb_E_C_Discount.Name = "txtb_E_C_Discount";
            this.txtb_E_C_Discount.Size = new System.Drawing.Size(141, 20);
            this.txtb_E_C_Discount.TabIndex = 39;
            // 
            // txtb_E_C_Credit_Balance
            // 
            this.txtb_E_C_Credit_Balance.Location = new System.Drawing.Point(387, 186);
            this.txtb_E_C_Credit_Balance.Name = "txtb_E_C_Credit_Balance";
            this.txtb_E_C_Credit_Balance.Size = new System.Drawing.Size(141, 20);
            this.txtb_E_C_Credit_Balance.TabIndex = 37;
            // 
            // txtb_E_C_IBAN
            // 
            this.txtb_E_C_IBAN.Location = new System.Drawing.Point(26, 186);
            this.txtb_E_C_IBAN.Name = "txtb_E_C_IBAN";
            this.txtb_E_C_IBAN.Size = new System.Drawing.Size(141, 20);
            this.txtb_E_C_IBAN.TabIndex = 36;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(23, 209);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(31, 13);
            this.label10.TabIndex = 42;
            this.label10.Text = "Limit:";
            // 
            // lbl_E_C_Customer
            // 
            this.lbl_E_C_Customer.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_E_C_Customer.Location = new System.Drawing.Point(6, 107);
            this.lbl_E_C_Customer.Name = "lbl_E_C_Customer";
            this.lbl_E_C_Customer.Size = new System.Drawing.Size(550, 23);
            this.lbl_E_C_Customer.TabIndex = 35;
            this.lbl_E_C_Customer.Text = "Customer Data";
            this.lbl_E_C_Customer.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(384, 250);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(84, 13);
            this.label8.TabIndex = 34;
            this.label8.Text = "Gross Revenue:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(384, 209);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(52, 13);
            this.label6.TabIndex = 32;
            this.label6.Text = "Discount:";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(384, 169);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(79, 13);
            this.label21.TabIndex = 30;
            this.label21.Text = "Credit Balance:";
            // 
            // label222
            // 
            this.label222.AutoSize = true;
            this.label222.Location = new System.Drawing.Point(23, 169);
            this.label222.Name = "label222";
            this.label222.Size = new System.Drawing.Size(35, 13);
            this.label222.TabIndex = 29;
            this.label222.Text = "IBAN:";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(26, 6);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(511, 78);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 28;
            this.pictureBox2.TabStop = false;
            // 
            // tcp_Customers
            // 
            this.tcp_Customers.AutoScroll = true;
            this.tcp_Customers.Controls.Add(this.customerPanel);
            this.tcp_Customers.Location = new System.Drawing.Point(4, 22);
            this.tcp_Customers.Name = "tcp_Customers";
            this.tcp_Customers.Size = new System.Drawing.Size(566, 460);
            this.tcp_Customers.TabIndex = 4;
            this.tcp_Customers.Text = "Customers";
            this.tcp_Customers.UseVisualStyleBackColor = true;
            // 
            // customerPanel
            // 
            this.customerPanel.AutoSize = true;
            this.customerPanel.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.customerPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.customerPanel.Controls.Add(this.btn_ShowAllCustomers);
            this.customerPanel.Location = new System.Drawing.Point(4, 35);
            this.customerPanel.MinimumSize = new System.Drawing.Size(540, 2);
            this.customerPanel.Name = "customerPanel";
            this.customerPanel.Size = new System.Drawing.Size(540, 25);
            this.customerPanel.TabIndex = 7;
            // 
            // btn_ShowAllCustomers
            // 
            this.btn_ShowAllCustomers.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.btn_ShowAllCustomers.Location = new System.Drawing.Point(0, 0);
            this.btn_ShowAllCustomers.Name = "btn_ShowAllCustomers";
            this.btn_ShowAllCustomers.Size = new System.Drawing.Size(538, 23);
            this.btn_ShowAllCustomers.TabIndex = 0;
            this.btn_ShowAllCustomers.Text = "Show All";
            this.btn_ShowAllCustomers.UseVisualStyleBackColor = true;
            this.btn_ShowAllCustomers.Click += new System.EventHandler(this.btn_ShowAllCustomers_Click);
            // 
            // tcp_Appointments
            // 
            this.tcp_Appointments.AutoScroll = true;
            this.tcp_Appointments.Controls.Add(this.appointmentsPanel);
            this.tcp_Appointments.Location = new System.Drawing.Point(4, 22);
            this.tcp_Appointments.Name = "tcp_Appointments";
            this.tcp_Appointments.Padding = new System.Windows.Forms.Padding(3);
            this.tcp_Appointments.Size = new System.Drawing.Size(566, 460);
            this.tcp_Appointments.TabIndex = 3;
            this.tcp_Appointments.Text = "Appointments";
            this.tcp_Appointments.UseVisualStyleBackColor = true;
            // 
            // appointmentsPanel
            // 
            this.appointmentsPanel.AutoSize = true;
            this.appointmentsPanel.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.appointmentsPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.appointmentsPanel.Controls.Add(this.btn_showallAppointments);
            this.appointmentsPanel.Location = new System.Drawing.Point(4, 35);
            this.appointmentsPanel.MinimumSize = new System.Drawing.Size(540, 2);
            this.appointmentsPanel.Name = "appointmentsPanel";
            this.appointmentsPanel.Size = new System.Drawing.Size(540, 25);
            this.appointmentsPanel.TabIndex = 7;
            // 
            // btn_showallAppointments
            // 
            this.btn_showallAppointments.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.btn_showallAppointments.Location = new System.Drawing.Point(0, 0);
            this.btn_showallAppointments.Name = "btn_showallAppointments";
            this.btn_showallAppointments.Size = new System.Drawing.Size(538, 23);
            this.btn_showallAppointments.TabIndex = 0;
            this.btn_showallAppointments.Text = "Show All";
            this.btn_showallAppointments.UseVisualStyleBackColor = true;
            this.btn_showallAppointments.Click += new System.EventHandler(this.btn_showallAppointments_Click);
            // 
            // tcp_AddInvoice
            // 
            this.tcp_AddInvoice.Controls.Add(this.dtp_Payment_Deadline);
            this.tcp_AddInvoice.Controls.Add(this.btn_Add_Invoice);
            this.tcp_AddInvoice.Controls.Add(this.lbl_Price);
            this.tcp_AddInvoice.Controls.Add(this.txtb_VAT);
            this.tcp_AddInvoice.Controls.Add(this.cbox_Project_Status);
            this.tcp_AddInvoice.Controls.Add(this.lbl_Invoice_Status);
            this.tcp_AddInvoice.Controls.Add(this.lbl_VAT);
            this.tcp_AddInvoice.Controls.Add(this.pictureBox1);
            this.tcp_AddInvoice.Controls.Add(this.cb_Select_Project);
            this.tcp_AddInvoice.Controls.Add(this.lbl_Project_id);
            this.tcp_AddInvoice.Location = new System.Drawing.Point(4, 22);
            this.tcp_AddInvoice.Name = "tcp_AddInvoice";
            this.tcp_AddInvoice.Padding = new System.Windows.Forms.Padding(3);
            this.tcp_AddInvoice.Size = new System.Drawing.Size(566, 460);
            this.tcp_AddInvoice.TabIndex = 2;
            this.tcp_AddInvoice.Text = "Add Invoice";
            this.tcp_AddInvoice.UseVisualStyleBackColor = true;
            // 
            // btn_Add_Invoice
            // 
            this.btn_Add_Invoice.Location = new System.Drawing.Point(481, 425);
            this.btn_Add_Invoice.Name = "btn_Add_Invoice";
            this.btn_Add_Invoice.Size = new System.Drawing.Size(75, 23);
            this.btn_Add_Invoice.TabIndex = 34;
            this.btn_Add_Invoice.Text = "Add invoice";
            this.btn_Add_Invoice.UseVisualStyleBackColor = true;
            this.btn_Add_Invoice.Click += new System.EventHandler(this.btn_Add_Invoice_Click);
            // 
            // lbl_Price
            // 
            this.lbl_Price.AutoSize = true;
            this.lbl_Price.Location = new System.Drawing.Point(316, 225);
            this.lbl_Price.Name = "lbl_Price";
            this.lbl_Price.Size = new System.Drawing.Size(94, 13);
            this.lbl_Price.TabIndex = 33;
            this.lbl_Price.Text = "Payment deadline:";
            // 
            // txtb_VAT
            // 
            this.txtb_VAT.Location = new System.Drawing.Point(319, 196);
            this.txtb_VAT.MaxLength = 2;
            this.txtb_VAT.Name = "txtb_VAT";
            this.txtb_VAT.Size = new System.Drawing.Size(100, 20);
            this.txtb_VAT.TabIndex = 28;
            this.txtb_VAT.Text = "21";
            // 
            // cbox_Project_Status
            // 
            this.cbox_Project_Status.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbox_Project_Status.Enabled = false;
            this.cbox_Project_Status.FormattingEnabled = true;
            this.cbox_Project_Status.Items.AddRange(new object[] {
            "Unpaid",
            "Paid"});
            this.cbox_Project_Status.Location = new System.Drawing.Point(27, 241);
            this.cbox_Project_Status.Name = "cbox_Project_Status";
            this.cbox_Project_Status.Size = new System.Drawing.Size(97, 21);
            this.cbox_Project_Status.TabIndex = 30;
            // 
            // lbl_Invoice_Status
            // 
            this.lbl_Invoice_Status.AutoSize = true;
            this.lbl_Invoice_Status.Location = new System.Drawing.Point(24, 225);
            this.lbl_Invoice_Status.Name = "lbl_Invoice_Status";
            this.lbl_Invoice_Status.Size = new System.Drawing.Size(75, 13);
            this.lbl_Invoice_Status.TabIndex = 31;
            this.lbl_Invoice_Status.Text = "Invoice Status";
            // 
            // lbl_VAT
            // 
            this.lbl_VAT.AutoSize = true;
            this.lbl_VAT.Location = new System.Drawing.Point(316, 180);
            this.lbl_VAT.Name = "lbl_VAT";
            this.lbl_VAT.Size = new System.Drawing.Size(28, 13);
            this.lbl_VAT.TabIndex = 29;
            this.lbl_VAT.Text = "VAT";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(26, 6);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(511, 78);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 27;
            this.pictureBox1.TabStop = false;
            // 
            // cb_Select_Project
            // 
            this.cb_Select_Project.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cb_Select_Project.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cb_Select_Project.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_Select_Project.FormattingEnabled = true;
            this.cb_Select_Project.Location = new System.Drawing.Point(27, 196);
            this.cb_Select_Project.MaxDropDownItems = 100;
            this.cb_Select_Project.Name = "cb_Select_Project";
            this.cb_Select_Project.Size = new System.Drawing.Size(286, 21);
            this.cb_Select_Project.TabIndex = 14;
            // 
            // lbl_Project_id
            // 
            this.lbl_Project_id.AutoSize = true;
            this.lbl_Project_id.Location = new System.Drawing.Point(23, 180);
            this.lbl_Project_id.Name = "lbl_Project_id";
            this.lbl_Project_id.Size = new System.Drawing.Size(52, 13);
            this.lbl_Project_id.TabIndex = 15;
            this.lbl_Project_id.Text = "Project Id";
            // 
            // tcp_Invoices
            // 
            this.tcp_Invoices.AutoScroll = true;
            this.tcp_Invoices.Controls.Add(this.btn_GoTo_Add_Invoice);
            this.tcp_Invoices.Controls.Add(this.invoicesPanel);
            this.tcp_Invoices.Location = new System.Drawing.Point(4, 22);
            this.tcp_Invoices.Name = "tcp_Invoices";
            this.tcp_Invoices.Padding = new System.Windows.Forms.Padding(3);
            this.tcp_Invoices.Size = new System.Drawing.Size(566, 460);
            this.tcp_Invoices.TabIndex = 1;
            this.tcp_Invoices.Text = "Invoices";
            this.tcp_Invoices.UseVisualStyleBackColor = true;
            // 
            // btn_GoTo_Add_Invoice
            // 
            this.btn_GoTo_Add_Invoice.Location = new System.Drawing.Point(3, 6);
            this.btn_GoTo_Add_Invoice.Name = "btn_GoTo_Add_Invoice";
            this.btn_GoTo_Add_Invoice.Size = new System.Drawing.Size(34, 23);
            this.btn_GoTo_Add_Invoice.TabIndex = 7;
            this.btn_GoTo_Add_Invoice.Text = "Add";
            this.btn_GoTo_Add_Invoice.UseVisualStyleBackColor = true;
            this.btn_GoTo_Add_Invoice.Click += new System.EventHandler(this.btn_GoTo_Add_Invoice_Click);
            // 
            // invoicesPanel
            // 
            this.invoicesPanel.AutoSize = true;
            this.invoicesPanel.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.invoicesPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.invoicesPanel.Controls.Add(this.btn_ShowAllInvoices);
            this.invoicesPanel.Location = new System.Drawing.Point(4, 35);
            this.invoicesPanel.MinimumSize = new System.Drawing.Size(540, 2);
            this.invoicesPanel.Name = "invoicesPanel";
            this.invoicesPanel.Size = new System.Drawing.Size(540, 25);
            this.invoicesPanel.TabIndex = 6;
            // 
            // btn_ShowAllInvoices
            // 
            this.btn_ShowAllInvoices.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.btn_ShowAllInvoices.Location = new System.Drawing.Point(0, 0);
            this.btn_ShowAllInvoices.Name = "btn_ShowAllInvoices";
            this.btn_ShowAllInvoices.Size = new System.Drawing.Size(538, 23);
            this.btn_ShowAllInvoices.TabIndex = 0;
            this.btn_ShowAllInvoices.Text = "Show All";
            this.btn_ShowAllInvoices.UseVisualStyleBackColor = true;
            this.btn_ShowAllInvoices.Click += new System.EventHandler(this.btn_ShowAllInvoices_Click);
            // 
            // tcp_Overview
            // 
            this.tcp_Overview.AutoScroll = true;
            this.tcp_Overview.Controls.Add(this.notificationsPanel);
            this.tcp_Overview.Controls.Add(this.label3);
            this.tcp_Overview.Location = new System.Drawing.Point(4, 22);
            this.tcp_Overview.Name = "tcp_Overview";
            this.tcp_Overview.Padding = new System.Windows.Forms.Padding(3);
            this.tcp_Overview.Size = new System.Drawing.Size(566, 460);
            this.tcp_Overview.TabIndex = 0;
            this.tcp_Overview.Text = "Overview";
            this.tcp_Overview.UseVisualStyleBackColor = true;
            // 
            // notificationsPanel
            // 
            this.notificationsPanel.AutoSize = true;
            this.notificationsPanel.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.notificationsPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.notificationsPanel.Controls.Add(this.btn_Show_All_Notifications);
            this.notificationsPanel.Location = new System.Drawing.Point(4, 35);
            this.notificationsPanel.MinimumSize = new System.Drawing.Size(540, 2);
            this.notificationsPanel.Name = "notificationsPanel";
            this.notificationsPanel.Size = new System.Drawing.Size(540, 25);
            this.notificationsPanel.TabIndex = 7;
            // 
            // btn_Show_All_Notifications
            // 
            this.btn_Show_All_Notifications.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.btn_Show_All_Notifications.Location = new System.Drawing.Point(0, 0);
            this.btn_Show_All_Notifications.Name = "btn_Show_All_Notifications";
            this.btn_Show_All_Notifications.Size = new System.Drawing.Size(538, 23);
            this.btn_Show_All_Notifications.TabIndex = 0;
            this.btn_Show_All_Notifications.Text = "Show All";
            this.btn_Show_All_Notifications.UseVisualStyleBackColor = true;
            this.btn_Show_All_Notifications.Click += new System.EventHandler(this.btn_Show_All_Notifications_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 12);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(0, 13);
            this.label3.TabIndex = 2;
            // 
            // tcp_Main
            // 
            this.tcp_Main.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tcp_Main.Controls.Add(this.tcp_Overview);
            this.tcp_Main.Controls.Add(this.tcp_Invoices);
            this.tcp_Main.Controls.Add(this.tcp_AddInvoice);
            this.tcp_Main.Controls.Add(this.tcp_Appointments);
            this.tcp_Main.Controls.Add(this.tcp_Customers);
            this.tcp_Main.Controls.Add(this.tcp_Edit_Customer);
            this.tcp_Main.Controls.Add(this.tcp_Help);
            this.tcp_Main.Location = new System.Drawing.Point(142, -21);
            this.tcp_Main.Margin = new System.Windows.Forms.Padding(0);
            this.tcp_Main.Name = "tcp_Main";
            this.tcp_Main.SelectedIndex = 0;
            this.tcp_Main.Size = new System.Drawing.Size(574, 486);
            this.tcp_Main.TabIndex = 4;
            this.tcp_Main.TabStop = false;
            this.tcp_Main.SelectedIndexChanged += new System.EventHandler(this.tc_Main_SelectedIndexChanged);
            // 
            // dtp_Payment_Deadline
            // 
            this.dtp_Payment_Deadline.CustomFormat = "yyyy/MM/dd";
            this.dtp_Payment_Deadline.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtp_Payment_Deadline.Location = new System.Drawing.Point(319, 242);
            this.dtp_Payment_Deadline.Name = "dtp_Payment_Deadline";
            this.dtp_Payment_Deadline.Size = new System.Drawing.Size(100, 20);
            this.dtp_Payment_Deadline.TabIndex = 35;
            // 
            // frm_Finance_2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(714, 461);
            this.Controls.Add(this.tcp_Main);
            this.Controls.Add(this.mstrp_Menu);
            this.Name = "frm_Finance_2";
            this.Text = "Barroc-IT - Software for real - Finance";
            this.mstrp_Menu.ResumeLayout(false);
            this.mstrp_Menu.PerformLayout();
            this.tcp_Help.ResumeLayout(false);
            this.tcp_Help.PerformLayout();
            this.tcp_Edit_Customer.ResumeLayout(false);
            this.tcp_Edit_Customer.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.tcp_Customers.ResumeLayout(false);
            this.tcp_Customers.PerformLayout();
            this.customerPanel.ResumeLayout(false);
            this.tcp_Appointments.ResumeLayout(false);
            this.tcp_Appointments.PerformLayout();
            this.appointmentsPanel.ResumeLayout(false);
            this.tcp_AddInvoice.ResumeLayout(false);
            this.tcp_AddInvoice.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tcp_Invoices.ResumeLayout(false);
            this.tcp_Invoices.PerformLayout();
            this.invoicesPanel.ResumeLayout(false);
            this.tcp_Overview.ResumeLayout(false);
            this.tcp_Overview.PerformLayout();
            this.notificationsPanel.ResumeLayout(false);
            this.tcp_Main.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.MenuStrip mstrp_Menu;
        private System.Windows.Forms.ToolStripMenuItem mnitem_Overview;
        private System.Windows.Forms.ToolStripMenuItem mnfltr_Overview_Department;
        private System.Windows.Forms.ToolStripComboBox tscmb_Overview_Department;
        private System.Windows.Forms.ToolStripMenuItem mnfltr_Overview_Type;
        private System.Windows.Forms.ToolStripComboBox tscmb_Overview_Type;
        private System.Windows.Forms.ToolStripMenuItem mnfltr_Overview_Date;
        private System.Windows.Forms.ToolStripMenuItem mnitem_Invoices;
        private System.Windows.Forms.ToolStripMenuItem mnfltr_Invoices_CuName;
        private System.Windows.Forms.ToolStripTextBox tstxtb_Invoices_CuName;
        private System.Windows.Forms.ToolStripMenuItem mnfltr_Invoices_CoName;
        private System.Windows.Forms.ToolStripTextBox tstxtb_Invoices_CoName;
        private System.Windows.Forms.ToolStripMenuItem mnfltr_Invoices_Paid;
        private System.Windows.Forms.ToolStripTextBox tstxtb_Projects_CuName;
        private System.Windows.Forms.ToolStripMenuItem mnitem_Appointments;
        private System.Windows.Forms.ToolStripMenuItem mnfltr_Appointments_CuName;
        private System.Windows.Forms.ToolStripTextBox tstxtb_Appointments_CuName;
        private System.Windows.Forms.ToolStripMenuItem mnfltr_Appointments_CoName;
        private System.Windows.Forms.ToolStripTextBox tstxtb_Appointments_CoName;
        private System.Windows.Forms.ToolStripMenuItem mnfltr_Appointments_Residence;
        private System.Windows.Forms.ToolStripTextBox tstxtb_Appointments_Residence;
        private System.Windows.Forms.ToolStripMenuItem mnfltr_Appointments_Summary;
        private System.Windows.Forms.ToolStripComboBox tscb_Appointments_Summary;
        private System.Windows.Forms.ToolStripMenuItem mnfltr_Appointments_Date;
        private System.Windows.Forms.ToolStripMenuItem mnitem_Help;
        private System.Windows.Forms.ToolStripMenuItem mnitem_Customers;
        private System.Windows.Forms.ToolStripMenuItem mnfltr_Customers_CuName;
        private System.Windows.Forms.ToolStripMenuItem mnfltr_Customers_CoName;
        private System.Windows.Forms.ToolStripMenuItem mnfltr_Customers_Residence;
        private System.Windows.Forms.ToolStripMenuItem mnfltr_Customers_UnpaidInvoice;
        private System.Windows.Forms.ToolStripMenuItem mnitem_Logout;
        private System.Windows.Forms.ToolStripTextBox tstxtb_Customers_CuName;
        private System.Windows.Forms.ToolStripTextBox tstxtb_Customer_CoName;
        private System.Windows.Forms.TabPage tcp_Help;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.RichTextBox richTextBox13;
        private System.Windows.Forms.RichTextBox richTextBox12;
        private System.Windows.Forms.RichTextBox richTextBox11;
        private System.Windows.Forms.RichTextBox richTextBox10;
        private System.Windows.Forms.RichTextBox richTextBox9;
        private System.Windows.Forms.RichTextBox richTextBox8;
        private System.Windows.Forms.RichTextBox richTextBox7;
        private System.Windows.Forms.RichTextBox richTextBox6;
        private System.Windows.Forms.RichTextBox richTextBox5;
        private System.Windows.Forms.RichTextBox richTextBox4;
        private System.Windows.Forms.RichTextBox richTextBox3;
        private System.Windows.Forms.RichTextBox richTextBox2;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TabPage tcp_Edit_Customer;
        private System.Windows.Forms.Label lbl_E_C_Customer_ID;
        private System.Windows.Forms.Button btn_Edit_Customer;
        private System.Windows.Forms.ComboBox cb_E_C_Prospect;
        private System.Windows.Forms.ComboBox cb_E_C_Creditworthy;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtb_E_C_Limit;
        private System.Windows.Forms.TextBox txtb_E_C_GrossRevenue;
        private System.Windows.Forms.TextBox txtb_E_C_Discount;
        private System.Windows.Forms.TextBox txtb_E_C_Credit_Balance;
        private System.Windows.Forms.TextBox txtb_E_C_IBAN;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label lbl_E_C_Customer;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label222;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.TabPage tcp_Customers;
        private System.Windows.Forms.Panel customerPanel;
        private System.Windows.Forms.Button btn_ShowAllCustomers;
        private System.Windows.Forms.TabPage tcp_Appointments;
        private System.Windows.Forms.Panel appointmentsPanel;
        private System.Windows.Forms.Button btn_showallAppointments;
        private System.Windows.Forms.TabPage tcp_AddInvoice;
        private System.Windows.Forms.Button btn_Add_Invoice;
        private System.Windows.Forms.Label lbl_Price;
        private System.Windows.Forms.TextBox txtb_VAT;
        private System.Windows.Forms.ComboBox cbox_Project_Status;
        private System.Windows.Forms.Label lbl_Invoice_Status;
        private System.Windows.Forms.Label lbl_VAT;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ComboBox cb_Select_Project;
        private System.Windows.Forms.Label lbl_Project_id;
        private System.Windows.Forms.TabPage tcp_Invoices;
        private System.Windows.Forms.Button btn_GoTo_Add_Invoice;
        private System.Windows.Forms.Panel invoicesPanel;
        private System.Windows.Forms.Button btn_ShowAllInvoices;
        private System.Windows.Forms.TabPage tcp_Overview;
        private System.Windows.Forms.Panel notificationsPanel;
        private System.Windows.Forms.Button btn_Show_All_Notifications;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TabControl tcp_Main;
        private System.Windows.Forms.DateTimePicker dtp_Payment_Deadline;
    }
}