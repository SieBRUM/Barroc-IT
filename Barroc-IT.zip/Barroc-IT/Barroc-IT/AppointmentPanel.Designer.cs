﻿namespace Barroc_IT
{
    partial class AppointmentPanel
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_Customer_Residence_Data = new System.Windows.Forms.Label();
            this.lbl_Customer_Residence = new System.Windows.Forms.Label();
            this.lbl_Customer_PhoneNumber_Data = new System.Windows.Forms.Label();
            this.lbl_Customer_PhoneNumber = new System.Windows.Forms.Label();
            this.lbl_Customer_Email_Data = new System.Windows.Forms.Label();
            this.lbl_Appointment_Time_Data = new System.Windows.Forms.Label();
            this.lbl_Customer_Zipcode_Data = new System.Windows.Forms.Label();
            this.lbl_Customer_Company_Name_Data = new System.Windows.Forms.Label();
            this.lbl_Customer_Address_Data = new System.Windows.Forms.Label();
            this.lbl_Appointment_Summary = new System.Windows.Forms.Label();
            this.rtb_Summary = new System.Windows.Forms.RichTextBox();
            this.lbl_Customer_Email = new System.Windows.Forms.Label();
            this.lbl_Appointment_Time = new System.Windows.Forms.Label();
            this.lbl_Customer_Zipcode = new System.Windows.Forms.Label();
            this.lbl_Customer_Address = new System.Windows.Forms.Label();
            this.lbl_Customer_Company_Name = new System.Windows.Forms.Label();
            this.lbl_Appointment_Date = new System.Windows.Forms.Label();
            this.lbl_CustomerName = new System.Windows.Forms.Label();
            this.lbl_hasSummary = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btn_Edit = new System.Windows.Forms.Button();
            this.lbl_Appointment_Made_Data = new System.Windows.Forms.Label();
            this.lbl_Appointment_Made = new System.Windows.Forms.Label();
            this.lbl_Appointment_Residence_Data = new System.Windows.Forms.Label();
            this.lbl_Appointment_Residence = new System.Windows.Forms.Label();
            this.lbl_Appointment_Address_Data = new System.Windows.Forms.Label();
            this.lbl_Appointment_Address = new System.Windows.Forms.Label();
            this.lbl_Appointment_Zipcode_Data = new System.Windows.Forms.Label();
            this.lbl_Appointment_Zipcode = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbl_Customer_Residence_Data
            // 
            this.lbl_Customer_Residence_Data.AutoSize = true;
            this.lbl_Customer_Residence_Data.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Customer_Residence_Data.Location = new System.Drawing.Point(101, 29);
            this.lbl_Customer_Residence_Data.Name = "lbl_Customer_Residence_Data";
            this.lbl_Customer_Residence_Data.Size = new System.Drawing.Size(74, 13);
            this.lbl_Customer_Residence_Data.TabIndex = 20;
            this.lbl_Customer_Residence_Data.Text = "Placeholder";
            // 
            // lbl_Customer_Residence
            // 
            this.lbl_Customer_Residence.AutoSize = true;
            this.lbl_Customer_Residence.Location = new System.Drawing.Point(12, 29);
            this.lbl_Customer_Residence.Name = "lbl_Customer_Residence";
            this.lbl_Customer_Residence.Size = new System.Drawing.Size(61, 13);
            this.lbl_Customer_Residence.TabIndex = 19;
            this.lbl_Customer_Residence.Text = "Residence:";
            // 
            // lbl_Customer_PhoneNumber_Data
            // 
            this.lbl_Customer_PhoneNumber_Data.AutoSize = true;
            this.lbl_Customer_PhoneNumber_Data.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Customer_PhoneNumber_Data.Location = new System.Drawing.Point(101, 97);
            this.lbl_Customer_PhoneNumber_Data.Name = "lbl_Customer_PhoneNumber_Data";
            this.lbl_Customer_PhoneNumber_Data.Size = new System.Drawing.Size(74, 13);
            this.lbl_Customer_PhoneNumber_Data.TabIndex = 18;
            this.lbl_Customer_PhoneNumber_Data.Text = "Placeholder";
            // 
            // lbl_Customer_PhoneNumber
            // 
            this.lbl_Customer_PhoneNumber.AutoSize = true;
            this.lbl_Customer_PhoneNumber.Location = new System.Drawing.Point(12, 97);
            this.lbl_Customer_PhoneNumber.Name = "lbl_Customer_PhoneNumber";
            this.lbl_Customer_PhoneNumber.Size = new System.Drawing.Size(79, 13);
            this.lbl_Customer_PhoneNumber.TabIndex = 17;
            this.lbl_Customer_PhoneNumber.Text = "Phone number:";
            // 
            // lbl_Customer_Email_Data
            // 
            this.lbl_Customer_Email_Data.AutoSize = true;
            this.lbl_Customer_Email_Data.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Customer_Email_Data.Location = new System.Drawing.Point(101, 80);
            this.lbl_Customer_Email_Data.Name = "lbl_Customer_Email_Data";
            this.lbl_Customer_Email_Data.Size = new System.Drawing.Size(74, 13);
            this.lbl_Customer_Email_Data.TabIndex = 15;
            this.lbl_Customer_Email_Data.Text = "Placeholder";
            // 
            // lbl_Appointment_Time_Data
            // 
            this.lbl_Appointment_Time_Data.AutoSize = true;
            this.lbl_Appointment_Time_Data.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Appointment_Time_Data.Location = new System.Drawing.Point(407, 12);
            this.lbl_Appointment_Time_Data.Name = "lbl_Appointment_Time_Data";
            this.lbl_Appointment_Time_Data.Size = new System.Drawing.Size(74, 13);
            this.lbl_Appointment_Time_Data.TabIndex = 14;
            this.lbl_Appointment_Time_Data.Text = "Placeholder";
            // 
            // lbl_Customer_Zipcode_Data
            // 
            this.lbl_Customer_Zipcode_Data.AutoSize = true;
            this.lbl_Customer_Zipcode_Data.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Customer_Zipcode_Data.Location = new System.Drawing.Point(101, 63);
            this.lbl_Customer_Zipcode_Data.Name = "lbl_Customer_Zipcode_Data";
            this.lbl_Customer_Zipcode_Data.Size = new System.Drawing.Size(74, 13);
            this.lbl_Customer_Zipcode_Data.TabIndex = 13;
            this.lbl_Customer_Zipcode_Data.Text = "Placeholder";
            // 
            // lbl_Customer_Company_Name_Data
            // 
            this.lbl_Customer_Company_Name_Data.AutoSize = true;
            this.lbl_Customer_Company_Name_Data.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Customer_Company_Name_Data.Location = new System.Drawing.Point(101, 12);
            this.lbl_Customer_Company_Name_Data.Name = "lbl_Customer_Company_Name_Data";
            this.lbl_Customer_Company_Name_Data.Size = new System.Drawing.Size(74, 13);
            this.lbl_Customer_Company_Name_Data.TabIndex = 12;
            this.lbl_Customer_Company_Name_Data.Text = "Placeholder";
            // 
            // lbl_Customer_Address_Data
            // 
            this.lbl_Customer_Address_Data.AutoSize = true;
            this.lbl_Customer_Address_Data.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Customer_Address_Data.Location = new System.Drawing.Point(101, 46);
            this.lbl_Customer_Address_Data.Name = "lbl_Customer_Address_Data";
            this.lbl_Customer_Address_Data.Size = new System.Drawing.Size(74, 13);
            this.lbl_Customer_Address_Data.TabIndex = 11;
            this.lbl_Customer_Address_Data.Text = "Placeholder";
            // 
            // lbl_Appointment_Summary
            // 
            this.lbl_Appointment_Summary.AutoSize = true;
            this.lbl_Appointment_Summary.Location = new System.Drawing.Point(12, 133);
            this.lbl_Appointment_Summary.Name = "lbl_Appointment_Summary";
            this.lbl_Appointment_Summary.Size = new System.Drawing.Size(53, 13);
            this.lbl_Appointment_Summary.TabIndex = 10;
            this.lbl_Appointment_Summary.Text = "Summary:";
            // 
            // rtb_Summary
            // 
            this.rtb_Summary.Location = new System.Drawing.Point(15, 149);
            this.rtb_Summary.Name = "rtb_Summary";
            this.rtb_Summary.ReadOnly = true;
            this.rtb_Summary.Size = new System.Drawing.Size(370, 69);
            this.rtb_Summary.TabIndex = 9;
            this.rtb_Summary.Text = "";
            // 
            // lbl_Customer_Email
            // 
            this.lbl_Customer_Email.AutoSize = true;
            this.lbl_Customer_Email.Location = new System.Drawing.Point(12, 80);
            this.lbl_Customer_Email.Name = "lbl_Customer_Email";
            this.lbl_Customer_Email.Size = new System.Drawing.Size(35, 13);
            this.lbl_Customer_Email.TabIndex = 8;
            this.lbl_Customer_Email.Text = "Email:";
            // 
            // lbl_Appointment_Time
            // 
            this.lbl_Appointment_Time.AutoSize = true;
            this.lbl_Appointment_Time.Location = new System.Drawing.Point(286, 12);
            this.lbl_Appointment_Time.Name = "lbl_Appointment_Time";
            this.lbl_Appointment_Time.Size = new System.Drawing.Size(91, 13);
            this.lbl_Appointment_Time.TabIndex = 6;
            this.lbl_Appointment_Time.Text = "Appointment time:";
            // 
            // lbl_Customer_Zipcode
            // 
            this.lbl_Customer_Zipcode.AutoSize = true;
            this.lbl_Customer_Zipcode.Location = new System.Drawing.Point(12, 63);
            this.lbl_Customer_Zipcode.Name = "lbl_Customer_Zipcode";
            this.lbl_Customer_Zipcode.Size = new System.Drawing.Size(49, 13);
            this.lbl_Customer_Zipcode.TabIndex = 5;
            this.lbl_Customer_Zipcode.Text = "Zipcode:";
            // 
            // lbl_Customer_Address
            // 
            this.lbl_Customer_Address.AutoSize = true;
            this.lbl_Customer_Address.Location = new System.Drawing.Point(12, 46);
            this.lbl_Customer_Address.Name = "lbl_Customer_Address";
            this.lbl_Customer_Address.Size = new System.Drawing.Size(48, 13);
            this.lbl_Customer_Address.TabIndex = 3;
            this.lbl_Customer_Address.Text = "Address:";
            // 
            // lbl_Customer_Company_Name
            // 
            this.lbl_Customer_Company_Name.AutoSize = true;
            this.lbl_Customer_Company_Name.Location = new System.Drawing.Point(12, 12);
            this.lbl_Customer_Company_Name.Name = "lbl_Customer_Company_Name";
            this.lbl_Customer_Company_Name.Size = new System.Drawing.Size(83, 13);
            this.lbl_Customer_Company_Name.TabIndex = 4;
            this.lbl_Customer_Company_Name.Text = "Company name:";
            // 
            // lbl_Appointment_Date
            // 
            this.lbl_Appointment_Date.AutoSize = true;
            this.lbl_Appointment_Date.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Appointment_Date.Location = new System.Drawing.Point(407, 17);
            this.lbl_Appointment_Date.Name = "lbl_Appointment_Date";
            this.lbl_Appointment_Date.Size = new System.Drawing.Size(106, 13);
            this.lbl_Appointment_Date.TabIndex = 2;
            this.lbl_Appointment_Date.Text = "Appointment date";
            this.lbl_Appointment_Date.Click += new System.EventHandler(this.OpenMoreInfo);
            // 
            // lbl_CustomerName
            // 
            this.lbl_CustomerName.AutoSize = true;
            this.lbl_CustomerName.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CustomerName.Location = new System.Drawing.Point(12, 17);
            this.lbl_CustomerName.Name = "lbl_CustomerName";
            this.lbl_CustomerName.Size = new System.Drawing.Size(93, 13);
            this.lbl_CustomerName.TabIndex = 1;
            this.lbl_CustomerName.Text = "Customer name";
            this.lbl_CustomerName.Click += new System.EventHandler(this.OpenMoreInfo);
            // 
            // lbl_hasSummary
            // 
            this.lbl_hasSummary.AutoSize = true;
            this.lbl_hasSummary.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_hasSummary.Location = new System.Drawing.Point(261, 17);
            this.lbl_hasSummary.Name = "lbl_hasSummary";
            this.lbl_hasSummary.Size = new System.Drawing.Size(81, 13);
            this.lbl_hasSummary.TabIndex = 0;
            this.lbl_hasSummary.Text = "Has summary";
            this.lbl_hasSummary.Click += new System.EventHandler(this.OpenMoreInfo);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.panel2.Controls.Add(this.btn_Edit);
            this.panel2.Controls.Add(this.lbl_Appointment_Made_Data);
            this.panel2.Controls.Add(this.lbl_Appointment_Made);
            this.panel2.Controls.Add(this.lbl_Appointment_Residence_Data);
            this.panel2.Controls.Add(this.lbl_Appointment_Residence);
            this.panel2.Controls.Add(this.lbl_Appointment_Address_Data);
            this.panel2.Controls.Add(this.lbl_Appointment_Address);
            this.panel2.Controls.Add(this.lbl_Appointment_Zipcode_Data);
            this.panel2.Controls.Add(this.lbl_Appointment_Zipcode);
            this.panel2.Controls.Add(this.lbl_Customer_Residence_Data);
            this.panel2.Controls.Add(this.lbl_Customer_Residence);
            this.panel2.Controls.Add(this.lbl_Customer_PhoneNumber_Data);
            this.panel2.Controls.Add(this.lbl_Customer_PhoneNumber);
            this.panel2.Controls.Add(this.lbl_Customer_Email_Data);
            this.panel2.Controls.Add(this.lbl_Appointment_Time_Data);
            this.panel2.Controls.Add(this.lbl_Customer_Zipcode_Data);
            this.panel2.Controls.Add(this.lbl_Customer_Company_Name_Data);
            this.panel2.Controls.Add(this.lbl_Customer_Address_Data);
            this.panel2.Controls.Add(this.lbl_Appointment_Summary);
            this.panel2.Controls.Add(this.rtb_Summary);
            this.panel2.Controls.Add(this.lbl_Customer_Email);
            this.panel2.Controls.Add(this.lbl_Appointment_Time);
            this.panel2.Controls.Add(this.lbl_Customer_Zipcode);
            this.panel2.Controls.Add(this.lbl_Customer_Address);
            this.panel2.Controls.Add(this.lbl_Customer_Company_Name);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 46);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(538, 235);
            this.panel2.TabIndex = 3;
            // 
            // btn_Edit
            // 
            this.btn_Edit.Location = new System.Drawing.Point(410, 209);
            this.btn_Edit.Name = "btn_Edit";
            this.btn_Edit.Size = new System.Drawing.Size(122, 23);
            this.btn_Edit.TabIndex = 30;
            this.btn_Edit.Text = "Edit Appointment";
            this.btn_Edit.UseVisualStyleBackColor = true;
            // 
            // lbl_Appointment_Made_Data
            // 
            this.lbl_Appointment_Made_Data.AutoSize = true;
            this.lbl_Appointment_Made_Data.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Appointment_Made_Data.Location = new System.Drawing.Point(408, 80);
            this.lbl_Appointment_Made_Data.Name = "lbl_Appointment_Made_Data";
            this.lbl_Appointment_Made_Data.Size = new System.Drawing.Size(74, 13);
            this.lbl_Appointment_Made_Data.TabIndex = 29;
            this.lbl_Appointment_Made_Data.Text = "Placeholder";
            // 
            // lbl_Appointment_Made
            // 
            this.lbl_Appointment_Made.AutoSize = true;
            this.lbl_Appointment_Made.Location = new System.Drawing.Point(287, 80);
            this.lbl_Appointment_Made.Name = "lbl_Appointment_Made";
            this.lbl_Appointment_Made.Size = new System.Drawing.Size(98, 13);
            this.lbl_Appointment_Made.TabIndex = 28;
            this.lbl_Appointment_Made.Text = "Appointment made:";
            // 
            // lbl_Appointment_Residence_Data
            // 
            this.lbl_Appointment_Residence_Data.AutoSize = true;
            this.lbl_Appointment_Residence_Data.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Appointment_Residence_Data.Location = new System.Drawing.Point(407, 29);
            this.lbl_Appointment_Residence_Data.Name = "lbl_Appointment_Residence_Data";
            this.lbl_Appointment_Residence_Data.Size = new System.Drawing.Size(74, 13);
            this.lbl_Appointment_Residence_Data.TabIndex = 27;
            this.lbl_Appointment_Residence_Data.Text = "Placeholder";
            // 
            // lbl_Appointment_Residence
            // 
            this.lbl_Appointment_Residence.AutoSize = true;
            this.lbl_Appointment_Residence.Location = new System.Drawing.Point(286, 29);
            this.lbl_Appointment_Residence.Name = "lbl_Appointment_Residence";
            this.lbl_Appointment_Residence.Size = new System.Drawing.Size(118, 13);
            this.lbl_Appointment_Residence.TabIndex = 26;
            this.lbl_Appointment_Residence.Text = "Appointment residence:";
            // 
            // lbl_Appointment_Address_Data
            // 
            this.lbl_Appointment_Address_Data.AutoSize = true;
            this.lbl_Appointment_Address_Data.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Appointment_Address_Data.Location = new System.Drawing.Point(407, 46);
            this.lbl_Appointment_Address_Data.Name = "lbl_Appointment_Address_Data";
            this.lbl_Appointment_Address_Data.Size = new System.Drawing.Size(74, 13);
            this.lbl_Appointment_Address_Data.TabIndex = 25;
            this.lbl_Appointment_Address_Data.Text = "Placeholder";
            // 
            // lbl_Appointment_Address
            // 
            this.lbl_Appointment_Address.AutoSize = true;
            this.lbl_Appointment_Address.Location = new System.Drawing.Point(286, 46);
            this.lbl_Appointment_Address.Name = "lbl_Appointment_Address";
            this.lbl_Appointment_Address.Size = new System.Drawing.Size(109, 13);
            this.lbl_Appointment_Address.TabIndex = 24;
            this.lbl_Appointment_Address.Text = "Appointment address:";
            // 
            // lbl_Appointment_Zipcode_Data
            // 
            this.lbl_Appointment_Zipcode_Data.AutoSize = true;
            this.lbl_Appointment_Zipcode_Data.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Appointment_Zipcode_Data.Location = new System.Drawing.Point(407, 63);
            this.lbl_Appointment_Zipcode_Data.Name = "lbl_Appointment_Zipcode_Data";
            this.lbl_Appointment_Zipcode_Data.Size = new System.Drawing.Size(74, 13);
            this.lbl_Appointment_Zipcode_Data.TabIndex = 23;
            this.lbl_Appointment_Zipcode_Data.Text = "Placeholder";
            // 
            // lbl_Appointment_Zipcode
            // 
            this.lbl_Appointment_Zipcode.AutoSize = true;
            this.lbl_Appointment_Zipcode.Location = new System.Drawing.Point(286, 63);
            this.lbl_Appointment_Zipcode.Name = "lbl_Appointment_Zipcode";
            this.lbl_Appointment_Zipcode.Size = new System.Drawing.Size(109, 13);
            this.lbl_Appointment_Zipcode.TabIndex = 22;
            this.lbl_Appointment_Zipcode.Text = "Appointment zipcode:";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.panel1.Controls.Add(this.lbl_Appointment_Date);
            this.panel1.Controls.Add(this.lbl_CustomerName);
            this.panel1.Controls.Add(this.lbl_hasSummary);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(538, 46);
            this.panel1.TabIndex = 2;
            this.panel1.Click += new System.EventHandler(this.OpenMoreInfo);
            this.panel1.DoubleClick += new System.EventHandler(this.OpenMoreInfo);
            // 
            // AppointmentPanel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.MinimumSize = new System.Drawing.Size(538, 0);
            this.Name = "AppointmentPanel";
            this.Size = new System.Drawing.Size(538, 281);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lbl_Customer_Residence_Data;
        private System.Windows.Forms.Label lbl_Customer_Residence;
        private System.Windows.Forms.Label lbl_Customer_PhoneNumber_Data;
        private System.Windows.Forms.Label lbl_Customer_PhoneNumber;
        private System.Windows.Forms.Label lbl_Customer_Email_Data;
        public System.Windows.Forms.Label lbl_Appointment_Time_Data;
        private System.Windows.Forms.Label lbl_Customer_Zipcode_Data;
        private System.Windows.Forms.Label lbl_Customer_Company_Name_Data;
        public System.Windows.Forms.Label lbl_Customer_Address_Data;
        private System.Windows.Forms.Label lbl_Appointment_Summary;
        private System.Windows.Forms.RichTextBox rtb_Summary;
        private System.Windows.Forms.Label lbl_Customer_Email;
        private System.Windows.Forms.Label lbl_Appointment_Time;
        private System.Windows.Forms.Label lbl_Customer_Zipcode;
        private System.Windows.Forms.Label lbl_Customer_Address;
        private System.Windows.Forms.Label lbl_Customer_Company_Name;
        private System.Windows.Forms.Label lbl_Appointment_Date;
        public System.Windows.Forms.Label lbl_CustomerName;
        private System.Windows.Forms.Label lbl_hasSummary;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
        public System.Windows.Forms.Label lbl_Appointment_Made_Data;
        private System.Windows.Forms.Label lbl_Appointment_Made;
        public System.Windows.Forms.Label lbl_Appointment_Residence_Data;
        private System.Windows.Forms.Label lbl_Appointment_Residence;
        public System.Windows.Forms.Label lbl_Appointment_Address_Data;
        private System.Windows.Forms.Label lbl_Appointment_Address;
        public System.Windows.Forms.Label lbl_Appointment_Zipcode_Data;
        private System.Windows.Forms.Label lbl_Appointment_Zipcode;
        public System.Windows.Forms.Button btn_Edit;

    }
}
