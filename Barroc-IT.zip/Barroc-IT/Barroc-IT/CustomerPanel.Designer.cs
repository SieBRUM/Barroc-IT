﻿namespace Barroc_IT
{
    partial class CustomerPanel
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel2 = new System.Windows.Forms.Panel();
            this.btn_editCustomer = new System.Windows.Forms.Button();
            this.lbl_Customer_Prospect = new System.Windows.Forms.Label();
            this.lbl_Prospect = new System.Windows.Forms.Label();
            this.lbl_Customer_Gross_Revenue = new System.Windows.Forms.Label();
            this.lbl_Gross_Revenue = new System.Windows.Forms.Label();
            this.lbl_Customer_Limit = new System.Windows.Forms.Label();
            this.lbl_Limit = new System.Windows.Forms.Label();
            this.lbl_Customer_Iban = new System.Windows.Forms.Label();
            this.lbl_Iban = new System.Windows.Forms.Label();
            this.lbl_Customer_Last_Contact = new System.Windows.Forms.Label();
            this.lbl_Last_Contact = new System.Windows.Forms.Label();
            this.lbl_Customer_Last_Action = new System.Windows.Forms.Label();
            this.lbl_Last_Action = new System.Windows.Forms.Label();
            this.lbl_Customer_Next_Contact = new System.Windows.Forms.Label();
            this.lbl_Next_Contact = new System.Windows.Forms.Label();
            this.lbl_Customer_Next_Action = new System.Windows.Forms.Label();
            this.lbl_Next_Action = new System.Windows.Forms.Label();
            this.lbl_Customer_Discount = new System.Windows.Forms.Label();
            this.lbl_Discount = new System.Windows.Forms.Label();
            this.lbl_Customer_Creditworthy = new System.Windows.Forms.Label();
            this.lbl_Creditworthy = new System.Windows.Forms.Label();
            this.lbl_Customer_Credit_Balance = new System.Windows.Forms.Label();
            this.lbl_Credit_Balance = new System.Windows.Forms.Label();
            this.lbl_Customer_Phonenumber_1 = new System.Windows.Forms.Label();
            this.lbl_Phonenumber_1 = new System.Windows.Forms.Label();
            this.lbl_Customer_Phonenumber_2 = new System.Windows.Forms.Label();
            this.lbl_Phonenumber_2 = new System.Windows.Forms.Label();
            this.lbl_Customer_Faxnumber = new System.Windows.Forms.Label();
            this.lbl_Faxnumber = new System.Windows.Forms.Label();
            this.lbl_Customer_Email = new System.Windows.Forms.Label();
            this.lbl_Email = new System.Windows.Forms.Label();
            this.lbl_Customer_NumofProjects = new System.Windows.Forms.Label();
            this.lbl_NumofProjects = new System.Windows.Forms.Label();
            this.lbl_Customer_Address_2 = new System.Windows.Forms.Label();
            this.lbl_Address_2 = new System.Windows.Forms.Label();
            this.lbl_Customer_Zipcode_1 = new System.Windows.Forms.Label();
            this.lbl_Zipcode_1 = new System.Windows.Forms.Label();
            this.lbl_Customer_Zipcode_2 = new System.Windows.Forms.Label();
            this.lbl_Zipcode_2 = new System.Windows.Forms.Label();
            this.lbl_Customer_Residence_1 = new System.Windows.Forms.Label();
            this.lbl_Residence_1 = new System.Windows.Forms.Label();
            this.lbl_Customer_Residence_2 = new System.Windows.Forms.Label();
            this.lbl_Residence_2 = new System.Windows.Forms.Label();
            this.lbl_Customer_Address_1 = new System.Windows.Forms.Label();
            this.lbl_Address_1 = new System.Windows.Forms.Label();
            this.lbl_Customer_CompanyName = new System.Windows.Forms.Label();
            this.lbl_CompanyName = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lbl_Unpaid_Invoice = new System.Windows.Forms.Label();
            this.lbl_Customer_ID = new System.Windows.Forms.Label();
            this.lbl_Customer_Name = new System.Windows.Forms.Label();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.AccessibleName = "Control";
            this.panel2.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.panel2.Controls.Add(this.btn_editCustomer);
            this.panel2.Controls.Add(this.lbl_Customer_Prospect);
            this.panel2.Controls.Add(this.lbl_Prospect);
            this.panel2.Controls.Add(this.lbl_Customer_Gross_Revenue);
            this.panel2.Controls.Add(this.lbl_Gross_Revenue);
            this.panel2.Controls.Add(this.lbl_Customer_Limit);
            this.panel2.Controls.Add(this.lbl_Limit);
            this.panel2.Controls.Add(this.lbl_Customer_Iban);
            this.panel2.Controls.Add(this.lbl_Iban);
            this.panel2.Controls.Add(this.lbl_Customer_Last_Contact);
            this.panel2.Controls.Add(this.lbl_Last_Contact);
            this.panel2.Controls.Add(this.lbl_Customer_Last_Action);
            this.panel2.Controls.Add(this.lbl_Last_Action);
            this.panel2.Controls.Add(this.lbl_Customer_Next_Contact);
            this.panel2.Controls.Add(this.lbl_Next_Contact);
            this.panel2.Controls.Add(this.lbl_Customer_Next_Action);
            this.panel2.Controls.Add(this.lbl_Next_Action);
            this.panel2.Controls.Add(this.lbl_Customer_Discount);
            this.panel2.Controls.Add(this.lbl_Discount);
            this.panel2.Controls.Add(this.lbl_Customer_Creditworthy);
            this.panel2.Controls.Add(this.lbl_Creditworthy);
            this.panel2.Controls.Add(this.lbl_Customer_Credit_Balance);
            this.panel2.Controls.Add(this.lbl_Credit_Balance);
            this.panel2.Controls.Add(this.lbl_Customer_Phonenumber_1);
            this.panel2.Controls.Add(this.lbl_Phonenumber_1);
            this.panel2.Controls.Add(this.lbl_Customer_Phonenumber_2);
            this.panel2.Controls.Add(this.lbl_Phonenumber_2);
            this.panel2.Controls.Add(this.lbl_Customer_Faxnumber);
            this.panel2.Controls.Add(this.lbl_Faxnumber);
            this.panel2.Controls.Add(this.lbl_Customer_Email);
            this.panel2.Controls.Add(this.lbl_Email);
            this.panel2.Controls.Add(this.lbl_Customer_NumofProjects);
            this.panel2.Controls.Add(this.lbl_NumofProjects);
            this.panel2.Controls.Add(this.lbl_Customer_Address_2);
            this.panel2.Controls.Add(this.lbl_Address_2);
            this.panel2.Controls.Add(this.lbl_Customer_Zipcode_1);
            this.panel2.Controls.Add(this.lbl_Zipcode_1);
            this.panel2.Controls.Add(this.lbl_Customer_Zipcode_2);
            this.panel2.Controls.Add(this.lbl_Zipcode_2);
            this.panel2.Controls.Add(this.lbl_Customer_Residence_1);
            this.panel2.Controls.Add(this.lbl_Residence_1);
            this.panel2.Controls.Add(this.lbl_Customer_Residence_2);
            this.panel2.Controls.Add(this.lbl_Residence_2);
            this.panel2.Controls.Add(this.lbl_Customer_Address_1);
            this.panel2.Controls.Add(this.lbl_Address_1);
            this.panel2.Controls.Add(this.lbl_Customer_CompanyName);
            this.panel2.Controls.Add(this.lbl_CompanyName);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 46);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(538, 364);
            this.panel2.TabIndex = 3;
            // 
            // btn_editCustomer
            // 
            this.btn_editCustomer.Location = new System.Drawing.Point(439, 329);
            this.btn_editCustomer.Name = "btn_editCustomer";
            this.btn_editCustomer.Size = new System.Drawing.Size(89, 23);
            this.btn_editCustomer.TabIndex = 83;
            this.btn_editCustomer.Text = "edit customer";
            this.btn_editCustomer.UseVisualStyleBackColor = true;
            // 
            // lbl_Customer_Prospect
            // 
            this.lbl_Customer_Prospect.AccessibleName = "Control";
            this.lbl_Customer_Prospect.AutoSize = true;
            this.lbl_Customer_Prospect.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Customer_Prospect.Location = new System.Drawing.Point(128, 223);
            this.lbl_Customer_Prospect.Name = "lbl_Customer_Prospect";
            this.lbl_Customer_Prospect.Size = new System.Drawing.Size(74, 13);
            this.lbl_Customer_Prospect.TabIndex = 82;
            this.lbl_Customer_Prospect.Text = "Placeholder";
            // 
            // lbl_Prospect
            // 
            this.lbl_Prospect.AutoSize = true;
            this.lbl_Prospect.Location = new System.Drawing.Point(12, 223);
            this.lbl_Prospect.Name = "lbl_Prospect";
            this.lbl_Prospect.Size = new System.Drawing.Size(52, 13);
            this.lbl_Prospect.TabIndex = 81;
            this.lbl_Prospect.Text = "Prospect:";
            // 
            // lbl_Customer_Gross_Revenue
            // 
            this.lbl_Customer_Gross_Revenue.AccessibleName = "Control";
            this.lbl_Customer_Gross_Revenue.AutoSize = true;
            this.lbl_Customer_Gross_Revenue.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Customer_Gross_Revenue.Location = new System.Drawing.Point(376, 104);
            this.lbl_Customer_Gross_Revenue.Name = "lbl_Customer_Gross_Revenue";
            this.lbl_Customer_Gross_Revenue.Size = new System.Drawing.Size(74, 13);
            this.lbl_Customer_Gross_Revenue.TabIndex = 80;
            this.lbl_Customer_Gross_Revenue.Text = "Placeholder";
            // 
            // lbl_Gross_Revenue
            // 
            this.lbl_Gross_Revenue.AutoSize = true;
            this.lbl_Gross_Revenue.Location = new System.Drawing.Point(292, 104);
            this.lbl_Gross_Revenue.Name = "lbl_Gross_Revenue";
            this.lbl_Gross_Revenue.Size = new System.Drawing.Size(79, 13);
            this.lbl_Gross_Revenue.TabIndex = 79;
            this.lbl_Gross_Revenue.Text = "Gross revenue:";
            // 
            // lbl_Customer_Limit
            // 
            this.lbl_Customer_Limit.AccessibleName = "Control";
            this.lbl_Customer_Limit.AutoSize = true;
            this.lbl_Customer_Limit.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Customer_Limit.Location = new System.Drawing.Point(376, 87);
            this.lbl_Customer_Limit.Name = "lbl_Customer_Limit";
            this.lbl_Customer_Limit.Size = new System.Drawing.Size(74, 13);
            this.lbl_Customer_Limit.TabIndex = 78;
            this.lbl_Customer_Limit.Text = "Placeholder";
            // 
            // lbl_Limit
            // 
            this.lbl_Limit.AutoSize = true;
            this.lbl_Limit.Location = new System.Drawing.Point(292, 87);
            this.lbl_Limit.Name = "lbl_Limit";
            this.lbl_Limit.Size = new System.Drawing.Size(31, 13);
            this.lbl_Limit.TabIndex = 77;
            this.lbl_Limit.Text = "Limit:";
            // 
            // lbl_Customer_Iban
            // 
            this.lbl_Customer_Iban.AccessibleName = "Control";
            this.lbl_Customer_Iban.AutoSize = true;
            this.lbl_Customer_Iban.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Customer_Iban.Location = new System.Drawing.Point(376, 70);
            this.lbl_Customer_Iban.Name = "lbl_Customer_Iban";
            this.lbl_Customer_Iban.Size = new System.Drawing.Size(74, 13);
            this.lbl_Customer_Iban.TabIndex = 76;
            this.lbl_Customer_Iban.Text = "Placeholder";
            // 
            // lbl_Iban
            // 
            this.lbl_Iban.AutoSize = true;
            this.lbl_Iban.Location = new System.Drawing.Point(292, 70);
            this.lbl_Iban.Name = "lbl_Iban";
            this.lbl_Iban.Size = new System.Drawing.Size(35, 13);
            this.lbl_Iban.TabIndex = 75;
            this.lbl_Iban.Text = "IBAN:";
            // 
            // lbl_Customer_Last_Contact
            // 
            this.lbl_Customer_Last_Contact.AccessibleName = "Control";
            this.lbl_Customer_Last_Contact.AutoSize = true;
            this.lbl_Customer_Last_Contact.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Customer_Last_Contact.Location = new System.Drawing.Point(128, 240);
            this.lbl_Customer_Last_Contact.Name = "lbl_Customer_Last_Contact";
            this.lbl_Customer_Last_Contact.Size = new System.Drawing.Size(74, 13);
            this.lbl_Customer_Last_Contact.TabIndex = 74;
            this.lbl_Customer_Last_Contact.Text = "Placeholder";
            // 
            // lbl_Last_Contact
            // 
            this.lbl_Last_Contact.AutoSize = true;
            this.lbl_Last_Contact.Location = new System.Drawing.Point(12, 240);
            this.lbl_Last_Contact.Name = "lbl_Last_Contact";
            this.lbl_Last_Contact.Size = new System.Drawing.Size(69, 13);
            this.lbl_Last_Contact.TabIndex = 73;
            this.lbl_Last_Contact.Text = "Last contact:";
            // 
            // lbl_Customer_Last_Action
            // 
            this.lbl_Customer_Last_Action.AccessibleName = "Control";
            this.lbl_Customer_Last_Action.AutoSize = true;
            this.lbl_Customer_Last_Action.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Customer_Last_Action.Location = new System.Drawing.Point(128, 257);
            this.lbl_Customer_Last_Action.Name = "lbl_Customer_Last_Action";
            this.lbl_Customer_Last_Action.Size = new System.Drawing.Size(74, 13);
            this.lbl_Customer_Last_Action.TabIndex = 72;
            this.lbl_Customer_Last_Action.Text = "Placeholder";
            // 
            // lbl_Last_Action
            // 
            this.lbl_Last_Action.AutoSize = true;
            this.lbl_Last_Action.Location = new System.Drawing.Point(12, 257);
            this.lbl_Last_Action.Name = "lbl_Last_Action";
            this.lbl_Last_Action.Size = new System.Drawing.Size(62, 13);
            this.lbl_Last_Action.TabIndex = 71;
            this.lbl_Last_Action.Text = "Last action:";
            // 
            // lbl_Customer_Next_Contact
            // 
            this.lbl_Customer_Next_Contact.AccessibleName = "Control";
            this.lbl_Customer_Next_Contact.AutoSize = true;
            this.lbl_Customer_Next_Contact.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Customer_Next_Contact.Location = new System.Drawing.Point(128, 274);
            this.lbl_Customer_Next_Contact.Name = "lbl_Customer_Next_Contact";
            this.lbl_Customer_Next_Contact.Size = new System.Drawing.Size(74, 13);
            this.lbl_Customer_Next_Contact.TabIndex = 70;
            this.lbl_Customer_Next_Contact.Text = "Placeholder";
            // 
            // lbl_Next_Contact
            // 
            this.lbl_Next_Contact.AutoSize = true;
            this.lbl_Next_Contact.Location = new System.Drawing.Point(12, 274);
            this.lbl_Next_Contact.Name = "lbl_Next_Contact";
            this.lbl_Next_Contact.Size = new System.Drawing.Size(71, 13);
            this.lbl_Next_Contact.TabIndex = 69;
            this.lbl_Next_Contact.Text = "Next contact:";
            // 
            // lbl_Customer_Next_Action
            // 
            this.lbl_Customer_Next_Action.AccessibleName = "Control";
            this.lbl_Customer_Next_Action.AutoSize = true;
            this.lbl_Customer_Next_Action.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Customer_Next_Action.Location = new System.Drawing.Point(128, 291);
            this.lbl_Customer_Next_Action.Name = "lbl_Customer_Next_Action";
            this.lbl_Customer_Next_Action.Size = new System.Drawing.Size(74, 13);
            this.lbl_Customer_Next_Action.TabIndex = 68;
            this.lbl_Customer_Next_Action.Text = "Placeholder";
            // 
            // lbl_Next_Action
            // 
            this.lbl_Next_Action.AutoSize = true;
            this.lbl_Next_Action.Location = new System.Drawing.Point(12, 291);
            this.lbl_Next_Action.Name = "lbl_Next_Action";
            this.lbl_Next_Action.Size = new System.Drawing.Size(64, 13);
            this.lbl_Next_Action.TabIndex = 67;
            this.lbl_Next_Action.Text = "Next action:";
            // 
            // lbl_Customer_Discount
            // 
            this.lbl_Customer_Discount.AccessibleName = "Control";
            this.lbl_Customer_Discount.AutoSize = true;
            this.lbl_Customer_Discount.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Customer_Discount.Location = new System.Drawing.Point(376, 53);
            this.lbl_Customer_Discount.Name = "lbl_Customer_Discount";
            this.lbl_Customer_Discount.Size = new System.Drawing.Size(74, 13);
            this.lbl_Customer_Discount.TabIndex = 66;
            this.lbl_Customer_Discount.Text = "Placeholder";
            // 
            // lbl_Discount
            // 
            this.lbl_Discount.AutoSize = true;
            this.lbl_Discount.Location = new System.Drawing.Point(292, 53);
            this.lbl_Discount.Name = "lbl_Discount";
            this.lbl_Discount.Size = new System.Drawing.Size(52, 13);
            this.lbl_Discount.TabIndex = 65;
            this.lbl_Discount.Text = "Discount:";
            // 
            // lbl_Customer_Creditworthy
            // 
            this.lbl_Customer_Creditworthy.AccessibleName = "Control";
            this.lbl_Customer_Creditworthy.AutoSize = true;
            this.lbl_Customer_Creditworthy.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Customer_Creditworthy.Location = new System.Drawing.Point(376, 36);
            this.lbl_Customer_Creditworthy.Name = "lbl_Customer_Creditworthy";
            this.lbl_Customer_Creditworthy.Size = new System.Drawing.Size(74, 13);
            this.lbl_Customer_Creditworthy.TabIndex = 64;
            this.lbl_Customer_Creditworthy.Text = "Placeholder";
            // 
            // lbl_Creditworthy
            // 
            this.lbl_Creditworthy.AutoSize = true;
            this.lbl_Creditworthy.Location = new System.Drawing.Point(292, 36);
            this.lbl_Creditworthy.Name = "lbl_Creditworthy";
            this.lbl_Creditworthy.Size = new System.Drawing.Size(68, 13);
            this.lbl_Creditworthy.TabIndex = 63;
            this.lbl_Creditworthy.Text = "Creditworthy:";
            // 
            // lbl_Customer_Credit_Balance
            // 
            this.lbl_Customer_Credit_Balance.AccessibleName = "Control";
            this.lbl_Customer_Credit_Balance.AutoSize = true;
            this.lbl_Customer_Credit_Balance.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Customer_Credit_Balance.Location = new System.Drawing.Point(376, 19);
            this.lbl_Customer_Credit_Balance.Name = "lbl_Customer_Credit_Balance";
            this.lbl_Customer_Credit_Balance.Size = new System.Drawing.Size(74, 13);
            this.lbl_Customer_Credit_Balance.TabIndex = 62;
            this.lbl_Customer_Credit_Balance.Text = "Placeholder";
            // 
            // lbl_Credit_Balance
            // 
            this.lbl_Credit_Balance.AutoSize = true;
            this.lbl_Credit_Balance.Location = new System.Drawing.Point(292, 19);
            this.lbl_Credit_Balance.Name = "lbl_Credit_Balance";
            this.lbl_Credit_Balance.Size = new System.Drawing.Size(78, 13);
            this.lbl_Credit_Balance.TabIndex = 61;
            this.lbl_Credit_Balance.Text = "Credit balance:";
            // 
            // lbl_Customer_Phonenumber_1
            // 
            this.lbl_Customer_Phonenumber_1.AccessibleName = "Control";
            this.lbl_Customer_Phonenumber_1.AutoSize = true;
            this.lbl_Customer_Phonenumber_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Customer_Phonenumber_1.Location = new System.Drawing.Point(128, 138);
            this.lbl_Customer_Phonenumber_1.Name = "lbl_Customer_Phonenumber_1";
            this.lbl_Customer_Phonenumber_1.Size = new System.Drawing.Size(74, 13);
            this.lbl_Customer_Phonenumber_1.TabIndex = 60;
            this.lbl_Customer_Phonenumber_1.Text = "Placeholder";
            // 
            // lbl_Phonenumber_1
            // 
            this.lbl_Phonenumber_1.AutoSize = true;
            this.lbl_Phonenumber_1.Location = new System.Drawing.Point(12, 138);
            this.lbl_Phonenumber_1.Name = "lbl_Phonenumber_1";
            this.lbl_Phonenumber_1.Size = new System.Drawing.Size(85, 13);
            this.lbl_Phonenumber_1.TabIndex = 59;
            this.lbl_Phonenumber_1.Text = "Phonenumber 1:";
            // 
            // lbl_Customer_Phonenumber_2
            // 
            this.lbl_Customer_Phonenumber_2.AccessibleName = "Control";
            this.lbl_Customer_Phonenumber_2.AutoSize = true;
            this.lbl_Customer_Phonenumber_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Customer_Phonenumber_2.Location = new System.Drawing.Point(128, 155);
            this.lbl_Customer_Phonenumber_2.Name = "lbl_Customer_Phonenumber_2";
            this.lbl_Customer_Phonenumber_2.Size = new System.Drawing.Size(74, 13);
            this.lbl_Customer_Phonenumber_2.TabIndex = 58;
            this.lbl_Customer_Phonenumber_2.Text = "Placeholder";
            // 
            // lbl_Phonenumber_2
            // 
            this.lbl_Phonenumber_2.AutoSize = true;
            this.lbl_Phonenumber_2.Location = new System.Drawing.Point(12, 155);
            this.lbl_Phonenumber_2.Name = "lbl_Phonenumber_2";
            this.lbl_Phonenumber_2.Size = new System.Drawing.Size(85, 13);
            this.lbl_Phonenumber_2.TabIndex = 57;
            this.lbl_Phonenumber_2.Text = "Phonenumber 2:";
            // 
            // lbl_Customer_Faxnumber
            // 
            this.lbl_Customer_Faxnumber.AccessibleName = "Control";
            this.lbl_Customer_Faxnumber.AutoSize = true;
            this.lbl_Customer_Faxnumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Customer_Faxnumber.Location = new System.Drawing.Point(128, 172);
            this.lbl_Customer_Faxnumber.Name = "lbl_Customer_Faxnumber";
            this.lbl_Customer_Faxnumber.Size = new System.Drawing.Size(74, 13);
            this.lbl_Customer_Faxnumber.TabIndex = 54;
            this.lbl_Customer_Faxnumber.Text = "Placeholder";
            // 
            // lbl_Faxnumber
            // 
            this.lbl_Faxnumber.AutoSize = true;
            this.lbl_Faxnumber.Location = new System.Drawing.Point(12, 172);
            this.lbl_Faxnumber.Name = "lbl_Faxnumber";
            this.lbl_Faxnumber.Size = new System.Drawing.Size(62, 13);
            this.lbl_Faxnumber.TabIndex = 53;
            this.lbl_Faxnumber.Text = "Faxnumber:";
            // 
            // lbl_Customer_Email
            // 
            this.lbl_Customer_Email.AccessibleName = "Control";
            this.lbl_Customer_Email.AutoSize = true;
            this.lbl_Customer_Email.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Customer_Email.Location = new System.Drawing.Point(128, 189);
            this.lbl_Customer_Email.Name = "lbl_Customer_Email";
            this.lbl_Customer_Email.Size = new System.Drawing.Size(74, 13);
            this.lbl_Customer_Email.TabIndex = 52;
            this.lbl_Customer_Email.Text = "Placeholder";
            // 
            // lbl_Email
            // 
            this.lbl_Email.AutoSize = true;
            this.lbl_Email.Location = new System.Drawing.Point(12, 189);
            this.lbl_Email.Name = "lbl_Email";
            this.lbl_Email.Size = new System.Drawing.Size(38, 13);
            this.lbl_Email.TabIndex = 51;
            this.lbl_Email.Text = "E-mail:";
            // 
            // lbl_Customer_NumofProjects
            // 
            this.lbl_Customer_NumofProjects.AccessibleName = "";
            this.lbl_Customer_NumofProjects.AutoSize = true;
            this.lbl_Customer_NumofProjects.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Customer_NumofProjects.Location = new System.Drawing.Point(128, 206);
            this.lbl_Customer_NumofProjects.Name = "lbl_Customer_NumofProjects";
            this.lbl_Customer_NumofProjects.Size = new System.Drawing.Size(74, 13);
            this.lbl_Customer_NumofProjects.TabIndex = 50;
            this.lbl_Customer_NumofProjects.Text = "Placeholder";
            // 
            // lbl_NumofProjects
            // 
            this.lbl_NumofProjects.AutoSize = true;
            this.lbl_NumofProjects.Location = new System.Drawing.Point(12, 206);
            this.lbl_NumofProjects.Name = "lbl_NumofProjects";
            this.lbl_NumofProjects.Size = new System.Drawing.Size(69, 13);
            this.lbl_NumofProjects.TabIndex = 49;
            this.lbl_NumofProjects.Text = "# of projects:";
            // 
            // lbl_Customer_Address_2
            // 
            this.lbl_Customer_Address_2.AccessibleName = "Control";
            this.lbl_Customer_Address_2.AutoSize = true;
            this.lbl_Customer_Address_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Customer_Address_2.Location = new System.Drawing.Point(128, 53);
            this.lbl_Customer_Address_2.Name = "lbl_Customer_Address_2";
            this.lbl_Customer_Address_2.Size = new System.Drawing.Size(74, 13);
            this.lbl_Customer_Address_2.TabIndex = 48;
            this.lbl_Customer_Address_2.Text = "Placeholder";
            // 
            // lbl_Address_2
            // 
            this.lbl_Address_2.AutoSize = true;
            this.lbl_Address_2.Location = new System.Drawing.Point(12, 53);
            this.lbl_Address_2.Name = "lbl_Address_2";
            this.lbl_Address_2.Size = new System.Drawing.Size(57, 13);
            this.lbl_Address_2.TabIndex = 47;
            this.lbl_Address_2.Text = "Address 2:";
            // 
            // lbl_Customer_Zipcode_1
            // 
            this.lbl_Customer_Zipcode_1.AccessibleName = "Control";
            this.lbl_Customer_Zipcode_1.AutoSize = true;
            this.lbl_Customer_Zipcode_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Customer_Zipcode_1.Location = new System.Drawing.Point(128, 70);
            this.lbl_Customer_Zipcode_1.Name = "lbl_Customer_Zipcode_1";
            this.lbl_Customer_Zipcode_1.Size = new System.Drawing.Size(74, 13);
            this.lbl_Customer_Zipcode_1.TabIndex = 46;
            this.lbl_Customer_Zipcode_1.Text = "Placeholder";
            // 
            // lbl_Zipcode_1
            // 
            this.lbl_Zipcode_1.AutoSize = true;
            this.lbl_Zipcode_1.Location = new System.Drawing.Point(12, 70);
            this.lbl_Zipcode_1.Name = "lbl_Zipcode_1";
            this.lbl_Zipcode_1.Size = new System.Drawing.Size(58, 13);
            this.lbl_Zipcode_1.TabIndex = 45;
            this.lbl_Zipcode_1.Text = "Zipcode 1:";
            // 
            // lbl_Customer_Zipcode_2
            // 
            this.lbl_Customer_Zipcode_2.AccessibleName = "Control";
            this.lbl_Customer_Zipcode_2.AutoSize = true;
            this.lbl_Customer_Zipcode_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Customer_Zipcode_2.Location = new System.Drawing.Point(128, 87);
            this.lbl_Customer_Zipcode_2.Name = "lbl_Customer_Zipcode_2";
            this.lbl_Customer_Zipcode_2.Size = new System.Drawing.Size(74, 13);
            this.lbl_Customer_Zipcode_2.TabIndex = 44;
            this.lbl_Customer_Zipcode_2.Text = "Placeholder";
            // 
            // lbl_Zipcode_2
            // 
            this.lbl_Zipcode_2.AutoSize = true;
            this.lbl_Zipcode_2.Location = new System.Drawing.Point(12, 87);
            this.lbl_Zipcode_2.Name = "lbl_Zipcode_2";
            this.lbl_Zipcode_2.Size = new System.Drawing.Size(58, 13);
            this.lbl_Zipcode_2.TabIndex = 43;
            this.lbl_Zipcode_2.Text = "Zipcode 2:";
            // 
            // lbl_Customer_Residence_1
            // 
            this.lbl_Customer_Residence_1.AccessibleName = "Control";
            this.lbl_Customer_Residence_1.AutoSize = true;
            this.lbl_Customer_Residence_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Customer_Residence_1.Location = new System.Drawing.Point(128, 104);
            this.lbl_Customer_Residence_1.Name = "lbl_Customer_Residence_1";
            this.lbl_Customer_Residence_1.Size = new System.Drawing.Size(74, 13);
            this.lbl_Customer_Residence_1.TabIndex = 42;
            this.lbl_Customer_Residence_1.Text = "Placeholder";
            // 
            // lbl_Residence_1
            // 
            this.lbl_Residence_1.AutoSize = true;
            this.lbl_Residence_1.Location = new System.Drawing.Point(12, 104);
            this.lbl_Residence_1.Name = "lbl_Residence_1";
            this.lbl_Residence_1.Size = new System.Drawing.Size(70, 13);
            this.lbl_Residence_1.TabIndex = 41;
            this.lbl_Residence_1.Text = "Residence 1:";
            // 
            // lbl_Customer_Residence_2
            // 
            this.lbl_Customer_Residence_2.AccessibleName = "Control";
            this.lbl_Customer_Residence_2.AutoSize = true;
            this.lbl_Customer_Residence_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Customer_Residence_2.Location = new System.Drawing.Point(128, 121);
            this.lbl_Customer_Residence_2.Name = "lbl_Customer_Residence_2";
            this.lbl_Customer_Residence_2.Size = new System.Drawing.Size(74, 13);
            this.lbl_Customer_Residence_2.TabIndex = 40;
            this.lbl_Customer_Residence_2.Text = "Placeholder";
            // 
            // lbl_Residence_2
            // 
            this.lbl_Residence_2.AutoSize = true;
            this.lbl_Residence_2.Location = new System.Drawing.Point(12, 121);
            this.lbl_Residence_2.Name = "lbl_Residence_2";
            this.lbl_Residence_2.Size = new System.Drawing.Size(70, 13);
            this.lbl_Residence_2.TabIndex = 39;
            this.lbl_Residence_2.Text = "Residence 2:";
            // 
            // lbl_Customer_Address_1
            // 
            this.lbl_Customer_Address_1.AccessibleName = "Control";
            this.lbl_Customer_Address_1.AutoSize = true;
            this.lbl_Customer_Address_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Customer_Address_1.Location = new System.Drawing.Point(128, 36);
            this.lbl_Customer_Address_1.Name = "lbl_Customer_Address_1";
            this.lbl_Customer_Address_1.Size = new System.Drawing.Size(74, 13);
            this.lbl_Customer_Address_1.TabIndex = 38;
            this.lbl_Customer_Address_1.Text = "Placeholder";
            // 
            // lbl_Address_1
            // 
            this.lbl_Address_1.AutoSize = true;
            this.lbl_Address_1.Location = new System.Drawing.Point(12, 36);
            this.lbl_Address_1.Name = "lbl_Address_1";
            this.lbl_Address_1.Size = new System.Drawing.Size(57, 13);
            this.lbl_Address_1.TabIndex = 37;
            this.lbl_Address_1.Text = "Address 1:";
            // 
            // lbl_Customer_CompanyName
            // 
            this.lbl_Customer_CompanyName.AccessibleName = "Control";
            this.lbl_Customer_CompanyName.AutoSize = true;
            this.lbl_Customer_CompanyName.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Customer_CompanyName.Location = new System.Drawing.Point(128, 19);
            this.lbl_Customer_CompanyName.Name = "lbl_Customer_CompanyName";
            this.lbl_Customer_CompanyName.Size = new System.Drawing.Size(74, 13);
            this.lbl_Customer_CompanyName.TabIndex = 36;
            this.lbl_Customer_CompanyName.Text = "Placeholder";
            // 
            // lbl_CompanyName
            // 
            this.lbl_CompanyName.AutoSize = true;
            this.lbl_CompanyName.Location = new System.Drawing.Point(12, 19);
            this.lbl_CompanyName.Name = "lbl_CompanyName";
            this.lbl_CompanyName.Size = new System.Drawing.Size(83, 13);
            this.lbl_CompanyName.TabIndex = 35;
            this.lbl_CompanyName.Text = "Company name:";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.panel1.Controls.Add(this.lbl_Unpaid_Invoice);
            this.panel1.Controls.Add(this.lbl_Customer_ID);
            this.panel1.Controls.Add(this.lbl_Customer_Name);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(538, 46);
            this.panel1.TabIndex = 2;
            this.panel1.Click += new System.EventHandler(this.ShowMoreInfo);
            this.panel1.DoubleClick += new System.EventHandler(this.ShowMoreInfo);
            // 
            // lbl_Unpaid_Invoice
            // 
            this.lbl_Unpaid_Invoice.AutoSize = true;
            this.lbl_Unpaid_Invoice.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Unpaid_Invoice.Location = new System.Drawing.Point(436, 17);
            this.lbl_Unpaid_Invoice.Name = "lbl_Unpaid_Invoice";
            this.lbl_Unpaid_Invoice.Size = new System.Drawing.Size(92, 13);
            this.lbl_Unpaid_Invoice.TabIndex = 2;
            this.lbl_Unpaid_Invoice.Text = "Unpaid invoice";
            this.lbl_Unpaid_Invoice.Click += new System.EventHandler(this.ShowMoreInfo);
            // 
            // lbl_Customer_ID
            // 
            this.lbl_Customer_ID.AutoSize = true;
            this.lbl_Customer_ID.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Customer_ID.Location = new System.Drawing.Point(12, 17);
            this.lbl_Customer_ID.Name = "lbl_Customer_ID";
            this.lbl_Customer_ID.Size = new System.Drawing.Size(76, 13);
            this.lbl_Customer_ID.TabIndex = 1;
            this.lbl_Customer_ID.Text = "Customer ID";
            this.lbl_Customer_ID.Click += new System.EventHandler(this.ShowMoreInfo);
            // 
            // lbl_Customer_Name
            // 
            this.lbl_Customer_Name.AutoSize = true;
            this.lbl_Customer_Name.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Customer_Name.Location = new System.Drawing.Point(203, 17);
            this.lbl_Customer_Name.Name = "lbl_Customer_Name";
            this.lbl_Customer_Name.Size = new System.Drawing.Size(95, 13);
            this.lbl_Customer_Name.TabIndex = 0;
            this.lbl_Customer_Name.Text = "Customer Name";
            this.lbl_Customer_Name.Click += new System.EventHandler(this.ShowMoreInfo);
            // 
            // CustomerPanel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.MinimumSize = new System.Drawing.Size(538, 0);
            this.Name = "CustomerPanel";
            this.Size = new System.Drawing.Size(538, 410);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lbl_Unpaid_Invoice;
        private System.Windows.Forms.Label lbl_Customer_ID;
        private System.Windows.Forms.Label lbl_Customer_Name;
        private System.Windows.Forms.Label lbl_Customer_CompanyName;
        private System.Windows.Forms.Label lbl_CompanyName;
        private System.Windows.Forms.Label lbl_Customer_Address_1;
        private System.Windows.Forms.Label lbl_Address_1;
        private System.Windows.Forms.Label lbl_Customer_Phonenumber_1;
        private System.Windows.Forms.Label lbl_Phonenumber_1;
        private System.Windows.Forms.Label lbl_Customer_Phonenumber_2;
        private System.Windows.Forms.Label lbl_Phonenumber_2;
        private System.Windows.Forms.Label lbl_Customer_Faxnumber;
        private System.Windows.Forms.Label lbl_Faxnumber;
        private System.Windows.Forms.Label lbl_Customer_Email;
        private System.Windows.Forms.Label lbl_Email;
        private System.Windows.Forms.Label lbl_Customer_NumofProjects;
        private System.Windows.Forms.Label lbl_NumofProjects;
        private System.Windows.Forms.Label lbl_Customer_Address_2;
        private System.Windows.Forms.Label lbl_Address_2;
        private System.Windows.Forms.Label lbl_Customer_Zipcode_1;
        private System.Windows.Forms.Label lbl_Zipcode_1;
        private System.Windows.Forms.Label lbl_Customer_Zipcode_2;
        private System.Windows.Forms.Label lbl_Zipcode_2;
        private System.Windows.Forms.Label lbl_Customer_Residence_1;
        private System.Windows.Forms.Label lbl_Residence_1;
        private System.Windows.Forms.Label lbl_Customer_Residence_2;
        private System.Windows.Forms.Label lbl_Residence_2;
        private System.Windows.Forms.Label lbl_Customer_Creditworthy;
        private System.Windows.Forms.Label lbl_Creditworthy;
        private System.Windows.Forms.Label lbl_Customer_Credit_Balance;
        private System.Windows.Forms.Label lbl_Credit_Balance;
        private System.Windows.Forms.Label lbl_Customer_Last_Contact;
        private System.Windows.Forms.Label lbl_Last_Contact;
        private System.Windows.Forms.Label lbl_Customer_Last_Action;
        private System.Windows.Forms.Label lbl_Last_Action;
        private System.Windows.Forms.Label lbl_Customer_Next_Contact;
        private System.Windows.Forms.Label lbl_Next_Contact;
        private System.Windows.Forms.Label lbl_Customer_Next_Action;
        private System.Windows.Forms.Label lbl_Next_Action;
        private System.Windows.Forms.Label lbl_Customer_Discount;
        private System.Windows.Forms.Label lbl_Discount;
        private System.Windows.Forms.Label lbl_Customer_Prospect;
        private System.Windows.Forms.Label lbl_Prospect;
        private System.Windows.Forms.Label lbl_Customer_Gross_Revenue;
        private System.Windows.Forms.Label lbl_Gross_Revenue;
        private System.Windows.Forms.Label lbl_Customer_Limit;
        private System.Windows.Forms.Label lbl_Limit;
        private System.Windows.Forms.Label lbl_Customer_Iban;
        private System.Windows.Forms.Label lbl_Iban;
        public System.Windows.Forms.Button btn_editCustomer;
    }
}
